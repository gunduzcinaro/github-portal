
%collect all animal names and blockpaths from user, label blockpaths with
animalNames={
'C34008A';
'C34009B';
};
blockpaths={'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Ext\C34008A_C34009B-230606-101545'...
'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Ext\C34008A_C34009B-230606-101545'...
};
whichStreams=[34;12];


%AUC time ranges
csonbsl_auc=[-5 0]; cson_auc=[0 30]; csoffbsl_auc=[25 30]; csoff_auc=[30 60];

TRANGE = [-5 65]; %  [-5 65] % window size [start time relative to epoc onset, window duration]
BSL_PER = [-5 0]; % [-5 0] % baseline period within our window
BSL_ITI_PER = [25 30];
N = 500;

groupNames={'CSUS','CS'};

groups= {'CSUS';'CSUS';'CSUS'}; 

numAnimals=numel(animalNames);
dataStruct_names=animalNames;
startTime=zeros(1,numAnimals);
Channel_405_name=animalNames;
Channel_465_name=animalNames;

%make table with all animal info

Table=table(animalNames,blockpaths',dataStruct_names,startTime',Channel_405_name,Channel_465_name,whichStreams);
Headers={'animalNames','blockpath','dataStruct_names','startTime','Channel_405_name','Channel_465_name','whichStreams'};
Table.Properties.VariableNames([1:7])=Headers;
% %fill in animal names

%%

%run TDTbin2mat on all of these, fill in the table, and store the datastructures in workspace
%for each animal....
zAll={}; minCols=0;
for aaa=1:numAnimals
    animalName=Table.animalNames{aaa};
    blockpath=Table.blockpath{aaa};
    whichStreams=Table.whichStreams(aaa);
        
    [zAllind, zerr,ts1,zBL4ITI,fsg1,F465,F405]=FP_ext_allbins_analysis_MX(animalName,blockpath,whichStreams,TRANGE,BSL_PER,BSL_ITI_PER,N);
%     [zBL4SHK]=FP_ext_US_analysis_MX(animalName, blockpath, whichStreams);
    zAll{aaa,1}=zAllind; %store z scores of individual animals in row of ZAll corresponding to animal 
    zBL4ITI_all{aaa,1}=zBL4ITI;
%     zBL4SHK_all{aaa,1}=zBL4SHK;
    rawf465{aaa,1}=F465;
    rawf405{aaa,1}=F405;
    
end
%%
%CONVERT TO MATRIX  - initially store in cell just in case data from dif
%files for some reason aren't the same length. If they aren't, code will
%error here but you won't lose zAll in cell array form
zall_mat=cell2mat(zAll);
clear zAll %clear zall_all to save space

zBL4ITI_mat=cell2mat(zBL4ITI_all);
clear zBL4ITI_all %clear zall_all to save space
% 
% zBL4SHK_mat=cell2mat(zBL4SHK_all);
% clear zBL4SHK_all %clear zall_all to save space

%GET AVERAGE ACROSS ALL ANIMALS, ALL CSs (basically assumes that all
%CSs is equal, and doesn't care which animal contributes which trial
zall_mean=mean(zall_mat,1);
sd_zall=std(zall_mat,1);
%GET AVERAGE ACROSS ALL ANIMALS, ALL ITIs - baselined to pre-US -(basically assumes that all
%CSs is equal, and doesn't care which animal contributes which trial
zall_mean_nBL=mean(zBL4ITI_mat,1);
sd_zall_nBL=std(zBL4ITI_mat,1);

% zall_mean_shk=mean(zBL4SHK_mat,1);
% sd_zall_shk=std(zBL4SHK_mat,1);
%%
%FIGURE 1: AVERAGE OF ALL ANIMALS, ALL CSs
%just looking at whole average before breaking down into bins...
figure (1)
hold on
a=0;

p1=patch([a a+28 a+28 a], [-4 -4 4 4], [.8 1 1], 'EdgeColor','none');
p4=patch([a+28 a+30 a+30 a+28], [-4 -4 4 4], [1 .8 .8], 'EdgeColor','none');


lo=zall_mean-sd_zall;
hi=zall_mean+sd_zall;
xxx1=[ts1, ts1(end:-1:1)];
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[ .8 .8 .8]); hold on;
set(hp1,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on;
set(gca,'Layer','Top')
plot(ts1,zall_mean);
title('All Animals, All CSs')

%%
%zall_mat (CS)
AUC=[]; % cue, shock
for qq = 1:size(zall_mat,1) %qq = 2:3:size(zall_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip== 1st 50 is mouse 1
    AUC(qq,1)=trapz(zall_mat(qq,ts1(1,:) >= csonbsl_auc(1) & ts1(1,:) < csonbsl_auc(2))); %baseline
    AUC(qq,2)=trapz(zall_mat(qq,ts1(1,:) >cson_auc(1) & ts1(1,:) < cson_auc(2))); %CS onset
    qq=qq+1;
end
AUC_mean = nanmean(AUC); %calculate mean ignoring NaNs
AUC_SEM = nanstd(AUC)/sqrt(numel(AUC(:,1))); %calculate SEM without NaNs

%zBL4ITI_mat (ITI)

for qq = 1:size(zBL4ITI_mat,1) %qq = 2:3:size(zBL4ITI_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC(qq,3)=trapz(zBL4ITI_mat(qq,ts1(1,:) >csoffbsl_auc(1) & ts1(1,:) < csoffbsl_auc(2))); %CS offset baseline
    AUC(qq,4)=trapz(zBL4ITI_mat(qq,ts1(1,:) >csoff_auc(1) & ts1(1,:) < csoff_auc(2))); %CS offset
    qq=qq+1;
end

% %zBL4SHK_mat (Shock)
% 
% for qq = 1:size(zBL4SHK_mat,1) %qq = 2:3:size(zBL4ITI_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
%     shk_AUC(qq,1)=trapz(zBL4SHK_mat(qq,ts1(1,:) >shkbsl_auc(1) & ts1(1,:) < shkbsl_auc(2))); %CS offset baseline
%     shk_AUC(qq,2)=trapz(zBL4SHK_mat(qq,ts1(1,:) >shk_auc(1) & ts1(1,:) < shk_auc(2))); %CS offset
%     qq=qq+1;
% end

AUC_mean = nanmean(AUC); %calculate mean ignoring NaNs
AUC_SEM = nanstd(AUC)/sqrt(numel(AUC(:,1))); %calculate SEM without NaNs

%%
%BINS: Now, we'll organize data into bins. For now, we'll do bins of 5 CSs
%per bin

z_bin5={};first5={};last5={};z_bin_nBL={};cson_aucbin={};csoff_aucbin={};normcson_aucbin={};normcsoff_aucbin={};
AUC_1 = AUC(:,1);AUC_2 = AUC(:,2);AUC_3 = AUC(:,3);AUC_4 = AUC(:,4);
bin_size=5; %modify this to change how many CSs per bin 1 to look one by one and 3 to look for all as bin!!!
CStot=50; %enter total number of CSs - you can have matlab look for this, but for now I'm just hard coding this value assuming ext is always 30 CSs
num_bins=CStot/bin_size;

csonbsltimes=csonbsl_auc(2)-csonbsl_auc(1);
csontimes=cson_auc(2)-cson_auc(1);
csoffbsltimes=csoffbsl_auc(2)-csoffbsl_auc(1);
csofftimes=csoff_auc(2)-csoff_auc(1);

for bin = 1:num_bins
    %set bin
    a=bin_size*(bin-1)+1;
    z_this_bin=[];z_this_bin_nBL=[];cson_thisbin=[];csoff_thisbin=[];normcson_thisbin=[];normcsoff_thisbin=[];
     
    %locate animal and compile first [bin size] for each animal
    for mouse=1:numAnimals
        
        start=50*(mouse-1);%this assumes there are n of X CSs per animal (which should be true, but careful if you change protocol)
        start=start+a; fin=start+4; % change this number according to bin number-1.!!!
        z_this_bin=[z_this_bin; zall_mat(start:fin,:)];
        z_this_bin_nBL=[z_this_bin_nBL; zBL4ITI_mat(start:fin,:)];
        cson_thisbin=[cson_thisbin; AUC_1(start:fin,:) AUC_2(start:fin,:)];
        csoff_thisbin=[csoff_thisbin; AUC_3(start:fin,:) AUC_4(start:fin,:)];
        normcson_thisbin=[normcson_thisbin; AUC_1(start:fin,:)/csonbsltimes AUC_2(start:fin,:)/csontimes];
        normcsoff_thisbin=[normcsoff_thisbin; AUC_3(start:fin,:)/csoffbsltimes AUC_4(start:fin,:)/csofftimes];
     
        if bin==1
            zCS1(mouse,:)=zall_mat(start,:);
            first5{mouse,1}=mean(zall_mat(start:fin,:),1); %average of first five CSs for each mouse (each mouse is one row)
            zs_bin1=z_this_bin; %will be helpful if you later need to exclude
            zs_bin1_nBL=z_this_bin_nBL; %will be helpful if you later need to exclude
      
        elseif bin ==num_bins
            last5{mouse,1}=mean(zall_mat(start:fin,:),1);%average of last five CSs for each mouse (each mouse is one row)
            zs_bin10=z_this_bin;%will be helpful if you later need to exclude
            zs_bin10_nBL=z_this_bin_nBL;
            
        end
    end
    
    %average across animals
    
    %Below will use each animal's data to find mean for each bin and SEM
    %across animals for that particular bin
    z_bin{bin,1}=mean(z_this_bin,1);
    bin_sd{bin,1}=(std(z_this_bin,1))./((numel(z_this_bin(:,1)))^.5);% sd is actually SEM as of 10/24/2019
    z_bin_nBL{bin,1}=mean(z_this_bin_nBL,1);
    bin_sd_nBL{bin,1}=(std(z_this_bin_nBL,1))./((numel(z_this_bin_nBL(:,1)))^.5);% sd is actually SEM as of 10/24/2019
    cson_aucbin{bin,1}=cson_thisbin;
    csoff_aucbin{bin,1}=csoff_thisbin;
    normcson_aucbin{bin,1}=normcson_thisbin;
    normcsoff_aucbin{bin,1}=normcsoff_thisbin;
end
%%
%Figure 2: First 5 CSs
%short traces

figure (2)
hold on
plot([0;0],[-20; 20],'--','color',[.8 .8 .8],'LineWidth',2);


%SD bin 1
lo=z_bin{1,1}-bin_sd{1,1};
hi=z_bin{1,1}+bin_sd{1,1};
% lo=mean_zbin1_ex-bin1_ex_sd;
% hi=mean_zbin1_ex+bin1_ex_sd;
xxx1=[ts1, ts1(end:-1:1)];%used to be ts1_all{1,:} instead of ts1? maybe related to OFL analysis
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[.96 .47 .49],'facealpha',.5); hold on; %old green was 0 .5 .1
set(hp1,'FaceColor', [.96 .47 .49],'EdgeColor','none');hold on;


% 
% %SD bin 10
% lo=z_bin{10,1}-bin_sd{10,1};
% hi=z_bin{10,1}+bin_sd{10,1};
% xxx1=[ts1_all{1,:}, ts1_all{1,:}(end:-1:1)];
% yyy1=[lo, hi(end:-1:1)];
% hp1= fill(xxx1,yyy1,[.56 .02 .03],'facealpha',.5); hold on;
% set(hp1,'FaceColor', [.56 .02 .03],'EdgeColor','none');hold on;



% p1to3=plot(ts1,mean_zbin1_ex,'color',[.96 .47 .49],'LineWidth',2);
p1to5=plot(ts1,z_bin{1,1},'color',[.96 .47 .49],'LineWidth',2); hold on; %light red


%add scale bar
% plot([-8; -7], [0;0],'-k', [0; 0], [7;8],'k', 'LineWidth',2);

% text(-4.2, -1.5, 'z=1', 'HorizontalAlignment','right');
% text(-3.5, -2.5, '1 s', 'HorizontalAlignment','center');
% set(gca, 'XTick',[],'XTickLabel',[],'xcolor',[1 1 1]);
title(' Early CS Onset') %Av Fisrt 5 CS bin
xlabel('Time(s)')
ylabel('Z-Score')
xlim([-5.5 30])
ylim([-2 4])
set(gca,'fontsize',20)
%%

%Figure 3: Last 5 CSs

%short traces
figure (3)
hold on
plot([0;0],[-20; 20],'--','color',[.8 .8 .8],'LineWidth',2);

% %SD bin 6 (bin 6 is last bin when binned into 5CSs)
lo=z_bin{10,1}-bin_sd{10,1};
hi=z_bin{10,1}+bin_sd{10,1};
xxx1=[ts1, ts1(end:-1:1)];
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[.56 .02 .03],'facealpha',.5); hold on;
set(hp1,'FaceColor', [.56 .02 .03],'EdgeColor','none');hold on;


 p46to50=plot(ts1,z_bin{10,1},'color',[.56 .02 .03],'LineWidth',2); hold on; %dark red

%add scale bar
% plot([-8; -7], [0;0],'-k', [0; 0], [7;8],'k', 'LineWidth',2);

% text(-4.2, -1.5, 'z=1', 'HorizontalAlignment','right');
% text(-3.5, -2.5, '1 s', 'HorizontalAlignment','center');
% set(gca, 'XTick',[],'XTickLabel',[],'xcolor',[1 1 1]);

xlim([-5.5 30.5])
ylim([-2 4])
title('Late CS Onset') %Av Last5 CS bin
xlabel('Time(s)')
ylabel('Z-Score')
set(gca,'fontsize',20)
%%
%Looking at ITI 
%Here, we'll baseline to t=25 to t=30 (taking t=0 to be CS onset)

%Figure 4: First 4 ITIs
%short traces

figure (4)
hold on
plot([30;30],[-20; 20],'--','color',[.8 .8 .8],'LineWidth',2);


%SD bin 1
lo=z_bin_nBL{1,1}-bin_sd_nBL{1,1};
hi=z_bin_nBL{1,1}+bin_sd_nBL{1,1};
% lo=mean_zbin1_ex-bin1_ex_sd;
% hi=mean_zbin1_ex+bin1_ex_sd;
xxx1=[ts1, ts1(end:-1:1)];%used to be ts1_all{1,:} instead of ts1? maybe related to OFL analysis
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[.96 .47 .49],'facealpha',.5); hold on; %old green was 0 .5 .1
set(hp1,'FaceColor', [.96 .47 .49],'EdgeColor','none');hold on;


% 
% %SD bin 10
% lo=z_bin{10,1}-bin_sd{10,1};
% hi=z_bin{10,1}+bin_sd{10,1};
% xxx1=[ts1_all{1,:}, ts1_all{1,:}(end:-1:1)];
% yyy1=[lo, hi(end:-1:1)];
% hp1= fill(xxx1,yyy1,[.56 .02 .03],'facealpha',.5); hold on;
% set(hp1,'FaceColor', [.56 .02 .03],'EdgeColor','none');hold on;



% p1to3=plot(ts1,mean_zbin1_ex,'color',[.96 .47 .49],'LineWidth',2);
p1to5=plot(ts1,z_bin_nBL{1,1},'color',[.96 .47 .49],'LineWidth',2); hold on; %light red


%add scale bar
% plot([-8; -7], [0;0],'-k', [0; 0], [7;8],'k', 'LineWidth',2);

% text(-4.2, -1.5, 'z=1', 'HorizontalAlignment','right');
% text(-3.5, -2.5, '1 s', 'HorizontalAlignment','center');
% set(gca, 'XTick',[],'XTickLabel',[],'xcolor',[1 1 1]);

xlim([24.5 60.5])
ylim([-2 4])
title('Early CS Offset') %Av First 5 ITI bin
xlabel('Time(s)')
ylabel('Z-Score')
set(gca,'fontsize',20)

%%

%Figure 5: Last 5 ITIs

%short traces
figure (5)
hold on
plot([30;30],[-20; 20],'--','color',[.8 .8 .8],'LineWidth',2);

% %SD bin 6 (bin 6 is last bin when binned into 5CSs)
lo=z_bin_nBL{10,1}-bin_sd_nBL{10,1};
hi=z_bin_nBL{10,1}+bin_sd_nBL{10,1};
xxx1=[ts1, ts1(end:-1:1)];
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[.56 .02 .03],'facealpha',.5); hold on;
set(hp1,'FaceColor', [.56 .02 .03],'EdgeColor','none');hold on;


 p46to50=plot(ts1,z_bin_nBL{10,1},'color',[.56 .02 .03],'LineWidth',2); hold on; %dark red

%add scale bar
% plot([-8; -7], [0;0],'-k', [0; 0], [7;8],'k', 'LineWidth',2);

% text(-4.2, -1.5, 'z=1', 'HorizontalAlignment','right');
% text(-3.5, -2.5, '1 s', 'HorizontalAlignment','center');
% set(gca, 'XTick',[],'XTickLabel',[],'xcolor',[1 1 1]);

xlim([25 60])
ylim([-2 4])
title('Late CS Offset') %Av Last 5 ITI bin
xlabel('Time(s)')
ylabel('Z-Score')
set(gca,'fontsize',20)

%%
% average AUC per animal
indcsonAUC_avg={};
indcsoffAUC_avg={};

tnindcsonAUC_avg={};
tnindcsoffAUC_avg={};

for i=1:numAnimals
    for n=1:size(cson_aucbin,1)
        indcsonAUC_avg{n,1}(i,1)=mean(cson_aucbin{n}(i*5-4:i*5,1));
        indcsonAUC_avg{n,1}(i,2)=mean(cson_aucbin{n}(i*5-4:i*5,2));
        indcsoffAUC_avg{n,1}(i,1)=mean(csoff_aucbin{n}(i*5-4:i*5,1));
        indcsoffAUC_avg{n,1}(i,2)=mean(csoff_aucbin{n}(i*5-4:i*5,2));

        tnindcsonAUC_avg{n,1}(i,1)=mean(normcson_aucbin{n}(i*5-4:i*5,1));
        tnindcsonAUC_avg{n,1}(i,2)=mean(normcson_aucbin{n}(i*5-4:i*5,2));
        tnindcsoffAUC_avg{n,1}(i,1)=mean(normcsoff_aucbin{n}(i*5-4:i*5,1));
        tnindcsoffAUC_avg{n,1}(i,2)=mean(normcsoff_aucbin{n}(i*5-4:i*5,2));
    end
end

%%
%export to excel- Early vs. Late

filename = 'GRAB AEAv1.5 IL-BLA CS-US Ext n=2 N=500.xlsx'; %name of file with exported data

names = [];
n=1;
while n<=numAnimals
    for j=1:5
        names = [names; animalNames{n}];
    end
    n=n+1;
end

num_CS = 5;
num_el = 1:numAnimals*num_CS;
mouse_num = ones(num_CS*numAnimals, 1);
animal_name = {};
for num=1:numAnimals
    for n=1:num_CS
        animal_name{end+1}= animalNames{num};
    end
end
CS_num = [];
for num=1:numAnimals
    mouse_num(num_CS*num-(num_CS-1):num_CS*num)=num;
    CS_num=[CS_num 1:num_CS];
end

sheetname = 'Z-Scores';

zscores=table(ts1.',z_bin{1,1}.',bin_sd{1,1}.',z_bin_nBL{1,1}.',bin_sd_nBL{1,1}.',z_bin{10,1}.',bin_sd{10,1}.',z_bin_nBL{10,1}.',bin_sd_nBL{10,1}.');
Headers={'Time'; 'Z-Score CS On Early'; 'SEM CS On Early'; 'Z-Score CS Off Early'; 'SEM CS Off Early';...
    'Z-Score CS On Late'; 'SEM CS On Late'; 'Z-Score CS Off Late'; 'SEM CS Off Late'};
zscores.Properties.VariableNames(1:9)=cellstr(Headers);

writetable(zscores, filename, 'Sheet', sheetname, 'Range', 'A1');

sheetname = 'Time Norm AUC';

timenormauc_table = {normcson_aucbin{1,1}; normcsoff_aucbin{1,1}; normcson_aucbin{10,1}; normcsoff_aucbin{10,1}};

timenormauc=table(num_el(:),mouse_num,animal_name.',CS_num(:),normcson_aucbin{1,1}(:,1),normcson_aucbin{1,1}(:,2),...
        normcsoff_aucbin{1,1}(:,1),normcsoff_aucbin{1,1}(:,2),normcson_aucbin{10,1}(:,1),normcson_aucbin{10,1}(:,2),...
        normcsoff_aucbin{10,1}(:,1),normcsoff_aucbin{10,1}(:,2));
Headers={'#', 'Mouse #', 'Mouse ID', 'CS #', 'CS On Early Pre', 'CS On Early Post', 'CS Off Early Pre',...
    'CS Off Early Post', 'CS On Late Pre', 'CS On Late Post', 'CS Off Late Pre', 'CS Off Late Post'};
timenormauc.Properties.VariableNames(1:12)=cellstr(Headers);

writetable(timenormauc, filename, 'Sheet', sheetname, 'Range', 'A1');

sheetname = 'Time Norm AUC per Animal';

tnind_auc=table(animalNames,tnindcsonAUC_avg{1},tnindcsoffAUC_avg{1},tnindcsonAUC_avg{10},tnindcsoffAUC_avg{10});
Headers = {'Mouse ID'; 'CS On Early'; 'CS Off Early'; 'CS On Late'; 'CS Off Late'};
tnind_auc.Properties.VariableNames(1:5)=cellstr(Headers);

writetable(tnind_auc, filename, 'Sheet', sheetname, 'Range', 'A1');

num_el = 1:numAnimals*50;
mouse_num = ones(50*numAnimals, 1);
CS_num = [];
names_50=[];
for num=1:numAnimals
    mouse_num(50*num-49:50*num)=num;
    CS_num=[CS_num 1:50];
    for i=1:50
        names_50 = [names_50; animalNames{num}];
    end
end

%writes out file with all AUCs unfiltered to check data
sheetname = 'AUC All';
auc_all=table(num_el(:),mouse_num,names_50,CS_num(:),AUC(:,1),AUC(:,2),AUC(:,3),AUC(:,4));
Headers = {'#'; 'Mouse #'; 'Mouse ID'; 'CS #'; 'AUC -5-0'; 'AUC 0-30'; 'AUC 25-30'; 'AUC 30-60'};
auc_all.Properties.VariableNames(1:8)=cellstr(Headers);

writetable(auc_all, filename, 'Sheet', sheetname, 'Range', 'A1');

%%

if(exist('hi_lo')==false) % not looking for hi/lo freezers

    columns_onset = {'ts1'; 'z_bin'; 'bin_sd'; 'Animal Name'; 'AUC '+string(csonbsl_auc(1))+'-'+string(csonbsl_auc(2)); 'AUC '+string(cson_auc(1))+'-'+string(cson_auc(2))}; %change name of columns based on data needed
    columns_offset = {'ts1'; 'z_bin'; 'bin_sd'; 'Animal Name'; 'AUC '+string(csoffbsl_auc(1))+'-'+string(csoffbsl_auc(2)); 
    'AUC '+string(csoff_auc(1))+'-'+string(csoff_auc(2))}; %change name of columns based on data needed
    
    for i=1:4
        writematrix(sheet{i}, filename, 'Sheet', sheet{i}, 'Range', 'A1');
        if i==1 || i==3
            writecell(columns_onset.', filename, 'Sheet', sheet{i}, 'Range', 'B1'); %column headers
    
        elseif i==2 || i==4
            writecell(columns_offset.', filename, 'Sheet', sheet{i}, 'Range', 'B1'); %column headers
        end
        writematrix(ts1.', filename, 'Sheet', sheet{i}, 'Range', 'B2'); %time stamps
        writematrix(z_mean(:,i), filename, 'Sheet', sheet{i}, 'Range', 'C2'); %z_mean
        writematrix(sd_z(:,i), filename, 'Sheet', sheet{i}, 'Range', 'D2'); %z_SEM
        writematrix(names, filename, 'Sheet', sheet{i}, 'Range', 'E2')
        writematrix(AUC_bsl{i}, filename, 'Sheet', sheet{i}, 'Range', 'F2');
        writematrix(AUC_bin{i}, filename, 'Sheet', sheet{i}, 'Range', 'G2');
    end

    col_1 = {'Animal Name'; 'CS Onset Early'; ''; 'CS Offset Early'; ''; 'CS Onset Late'; ''; 'CS Offset Late'};
    col_2 = {'Pre'; 'Post'; 'Pre'; 'Post'; 'Pre'; 'Post'; 'Pre'; 'Post'};
    sheetname = 'Time Norm AUC';
    
    writecell(col_1.', filename, 'Sheet', sheetname, 'Range', 'A1');
    writecell(col_2.', filename, 'Sheet', sheetname, 'Range', 'B2');
    writematrix(names, filename, 'Sheet', sheetname, 'Range', 'A3')
    writematrix(earlyonsetbsl(:)/(csonbsl_auc(2)-csonbsl_auc(1)), filename, 'Sheet', sheetname, 'Range', 'B3');
    writematrix(onset_early(:)/(cson_auc(2)-cson_auc(1)), filename, 'Sheet', sheetname, 'Range', 'C3');
    writematrix(earlyoffsetbsl(:)/(csoffbsl_auc(2)-csoffbsl_auc(1)), filename, 'Sheet', sheetname, 'Range', 'D3');
    writematrix(offset_early(:)/(csoff_auc(2)-csoff_auc(1)), filename, 'Sheet', sheetname, 'Range', 'E3');
    writematrix(lateonsetbsl(:)/(csonbsl_auc(2)-csonbsl_auc(1)), filename, 'Sheet', sheetname, 'Range', 'F3');
    writematrix(onset_late(:)/(cson_auc(2)-cson_auc(1)), filename, 'Sheet', sheetname, 'Range', 'G3');
    writematrix(lateoffsetbsl(:)/(csoffbsl_auc(2)-csoffbsl_auc(1)), filename, 'Sheet', sheetname, 'Range', 'H3');
    writematrix(offset_late(:)/(csoff_auc(2)-csoff_auc(1)), filename, 'Sheet', sheetname, 'Range', 'I3');
    
    %writes out file with all AUCs unfiltered to check data
    col = {'#'; 'Mouse #'; 'Mouse ID'; 'CS #'; 'AUC -5-0'; 'AUC 0-30'; 'AUC 25-30'; 'AUC 30-60'};
    sheetname = 'AUC Ext';

    writecell(col.', filename, 'Sheet', sheetname, 'Range', 'A1');
    writematrix(num_el(:), filename, 'Sheet', sheetname, 'Range', 'A2');
    writematrix(mouse_num, filename, 'Sheet', sheetname, 'Range', 'B2');
    writematrix(names_50, filename, 'Sheet', sheetname, 'Range', 'C2')
    writematrix(CS_num(:), filename, 'Sheet', sheetname, 'Range', 'D2');
    writematrix(AUC(:,1), filename, 'Sheet', sheetname, 'Range', 'E2'); %AUC -5-0
    writematrix(AUC(:,2), filename, 'Sheet', sheetname, 'Range', 'F2'); %AUC 0-5
    writematrix(AUC(:,3), filename, 'Sheet', sheetname, 'Range', 'G2'); %AUC 25-30
    writematrix(AUC(:,4), filename, 'Sheet', sheetname, 'Range', 'H2'); %AUC 30-35

else % if looking for hi/lo freezers
    columns_onset = {'ts1'; 'z_bin'; 'bin_sd'; 'Animal Name'; 'Hi/Lo'; 'AUC -5-0'; 'AUC 0-30'}; %change name of columns based on data needed
    columns_offset = {'ts1'; 'z_bin'; 'bin_sd'; 'Animal Name'; 'Hi/Lo'; 'AUC 25-30'; 'AUC 30-60'}; %change name of columns based on data needed

    for i=1:4
        writematrix(sheet{i}, filename, 'Sheet', sheet{i}, 'Range', 'A1');
        if i==1 || i==3
            writecell(columns_onset.', filename, 'Sheet', sheet{i}, 'Range', 'B1'); %column headers
    
        elseif i==2 || i==4
            writecell(columns_offset.', filename, 'Sheet', sheet{i}, 'Range', 'B1'); %column headers
        end
        writematrix(ts1.', filename, 'Sheet', sheet{i}, 'Range', 'B2'); %time stamps
        writematrix(z_mean(:,i), filename, 'Sheet', sheet{i}, 'Range', 'C2'); %z_mean
        writematrix(sd_z(:,i), filename, 'Sheet', sheet{i}, 'Range', 'D2'); %z_SEM
        writematrix(names, filename, 'Sheet', sheet{i}, 'Range', 'E2')
        writematrix(hilo, filename, 'Sheet', sheet{i}, 'Range', 'F2')
        writematrix(AUC_bsl{i}, filename, 'Sheet', sheet{i}, 'Range', 'G2');
        writematrix(AUC_bin{i}, filename, 'Sheet', sheet{i}, 'Range', 'H2');
    end

    col_1 = {'Animal Name'; 'Hi/Lo'; 'CS Onset Early'; ''; 'CS Offset Early'; ''; 'CS Onset Late'; ''; 'CS Offset Late'};
    col_2 = {'Pre'; 'Post'; 'Pre'; 'Post'; 'Pre'; 'Post'; 'Pre'; 'Post'};
    sheetname = 'Time Norm AUC';
    
    writecell(col_1.', filename, 'Sheet', sheetname, 'Range', 'A1');
    writecell(col_2.', filename, 'Sheet', sheetname, 'Range', 'C2');
    writematrix(names, filename, 'Sheet', sheetname, 'Range', 'A3')
    writematrix(hilo, filename, 'Sheet', sheetname, 'Range', 'B3')
    writematrix(earlyonsetbsl(:)/(csonbsl_auc(2)-csonbsl_auc(1)), filename, 'Sheet', sheetname, 'Range', 'C3');
    writematrix(onset_early(:)/(cson_auc(2)-cson_auc(1)), filename, 'Sheet', sheetname, 'Range', 'D3');
    writematrix(earlyoffsetbsl(:)/(csoffbsl_auc(2)-csoffbsl_auc(1)), filename, 'Sheet', sheetname, 'Range', 'E3');
    writematrix(offset_early(:)/(csoff_auc(2)-csoff_auc(1)), filename, 'Sheet', sheetname, 'Range', 'F3');
    writematrix(lateonsetbsl(:)/(csonbsl_auc(2)-csonbsl_auc(1)), filename, 'Sheet', sheetname, 'Range', 'G3');
    writematrix(onset_late(:)/(cson_auc(2)-cson_auc(1)), filename, 'Sheet', sheetname, 'Range', 'H3');
    writematrix(lateoffsetbsl(:)/(csoffbsl_auc(2)-csoffbsl_auc(1)), filename, 'Sheet', sheetname, 'Range', 'I3');
    writematrix(offset_late(:)/(csoff_auc(2)-csoff_auc(1)), filename, 'Sheet', sheetname, 'Range', 'J3');
    
    %writes out file with all AUCs unfiltered to check data
    col = {'#'; 'Mouse #'; 'Mouse ID'; 'Hi/Lo'; 'CS #'; 'AUC -5-0'; 'AUC 0-30'; 'AUC 25-30'; 'AUC 30-60'};
    sheetname = 'AUC Ext';
    
    writecell(col.', filename, 'Sheet', sheetname, 'Range', 'A1');
    writematrix(num_el(:), filename, 'Sheet', sheetname, 'Range', 'A2');
    writematrix(mouse_num, filename, 'Sheet', sheetname, 'Range', 'B2');
    writematrix(names_50, filename, 'Sheet', sheetname, 'Range', 'C2')
    writematrix(hilo, filename, 'Sheet', sheetname, 'Range', 'D2');
    writematrix(CS_num(:), filename, 'Sheet', sheetname, 'Range', 'E2');
    writematrix(AUC(:,1), filename, 'Sheet', sheetname, 'Range', 'F2'); %AUC -5-0
    writematrix(AUC(:,2), filename, 'Sheet', sheetname, 'Range', 'G2'); %AUC 0-5
    writematrix(AUC(:,3), filename, 'Sheet', sheetname, 'Range', 'H2'); %AUC 25-30
    writematrix(AUC(:,4), filename, 'Sheet', sheetname, 'Range', 'I2'); %AUC 30-35
end

%%
%export time normalized CS to Excel- All Bins

filename = 'Binned AUCs intraBLA RIM GRABeCBv2.0 IL-BLA CS-US Ext n=6 N=500.xlsx'; %name of file with exported data
sheetname='Z-Scores CS Onset';
bins_cson=[];
for i=1:num_bins
    bins_cson(:,i*2-1:i*2)=[z_bin{i,1}.' bin_sd{i,1}.'];
end

zscore_cson=array2table(bins_cson);
zscore_cson.Properties.VariableNames(1:20)={'z_bin{1,1}', 'bin_sd{1,1}', 'z_bin{2,1}', 'bin_sd{2,1}', 'z_bin{3,1}', 'bin_sd{3,1}',... 
    'z_bin{4,1}', 'bin_sd{4,1}', 'z_bin{5,1}', 'bin_sd{5,1}', 'z_bin{6,1}', 'bin_sd{6,1}', 'z_bin{7,1}', 'bin_sd{7,1}',... 
   'z_bin{8,1}', 'bin_sd{8,1}', 'z_bin{9,1}', 'bin_sd{9,1}', 'z_bin{10,1}', 'bin_sd{10,1}'};

writematrix('Time', filename, 'Sheet', sheetname, 'Range', 'A1')
writematrix(ts1.', filename, 'Sheet', sheetname, 'Range', 'A2');
writetable(zscore_cson, filename, 'Sheet', sheetname, 'Range', 'B1');

sheetname='Z-Scores CS Offset';

bins_csoff=[];
for i=1:num_bins
    bins_csoff(:,i*2-1:i*2)=[z_bin_nBL{i,1}.' bin_sd_nBL{i,1}.'];
end

zscore_csoff=array2table(bins_cson);
zscore_csoff.Properties.VariableNames(1:20)={'z_bin_nBL{1,1}', 'bin_sd_nBL{1,1}', 'z_bin_nBL{2,1}', 'bin_sd_nBL{2,1}', 'z_bin_nBL{3,1}', 'bin_sd_nBL{3,1}',... 
    'z_bin_nBL{4,1}', 'bin_sd_nBL{4,1}', 'z_bin_nBL{5,1}', 'bin_sd_nBL{5,1}', 'z_bin_nBL{6,1}', 'bin_sd_nBL{6,1}', 'z_bin_nBL{7,1}', 'bin_sd_nBL{7,1}',... 
   'z_bin_nBL{8,1}', 'bin_sd_nBL{8,1}', 'z_bin_nBL{9,1}', 'bin_sd_nBL{9,1}', 'z_bin_nBL{10,1}', 'bin_sd_nBL{10,1}'};

writematrix('Time', filename, 'Sheet', sheetname, 'Range', 'A1')
writematrix(ts1.', filename, 'Sheet', sheetname, 'Range', 'A2');
writetable(zscore_csoff, filename, 'Sheet', sheetname, 'Range', 'B1');

animal_name = {};
for num=1:numAnimals
    for n=1:bin_size
        animal_name{end+1}= animalNames{num};
    end
end

sheetname = 'Time Norm CS Onset';
bins_auccson=[];
for i=1:num_bins
    bins_auccson(:,i*2-1:i*2)=[normcson_aucbin{i,1}];
end
auc_cson=array2table(bins_auccson);
auc_cson.Properties.VariableNames(1:20)={'Bin 1 Bsl Onset', 'Bin 1 Onset', 'Bin 2 Bsl Onset', 'Bin 2 Onset','Bin 3 Bsl Onset', 'Bin 3 Onset',... 
    'Bin 4 Bsl Onset', 'Bin 4 Onset', 'Bin 5 Bsl Onset', 'Bin 5 Onset', 'Bin 6 Bsl Onset', 'Bin 6 Onset', 'Bin 7 Bsl Onset', 'Bin 7 Onset',... 
   'Bin 8 Bsl Onset', 'Bin 8 Onset', 'Bin 9 Bsl Onset', 'Bin 9 Onset', 'Bin 10 Bsl Onset', 'Bin 10 Onset'};
writematrix('Time', filename, 'Sheet', sheetname, 'Range', 'A1');
writematrix(ts1.', filename,'Sheet', sheetname, 'Range', 'A2');
writetable(auc_cson, filename, 'Sheet', sheetname, 'Range', 'B1');

sheetname = 'Time Norm CS Offset';
bins_auccsoff=[];
for i=1:num_bins
    bins_auccsoff(:,i*2-1:i*2)=[normcsoff_aucbin{i,1}];
end
auc_csoff=array2table(bins_auccsoff);
auc_csoff.Properties.VariableNames(1:20)={'Bin 1 Bsl Offset', 'Bin 1 Offset', 'Bin 2 Bsl Offset', 'Bin 2 Offset','Bin 3 Bsl Offset', 'Bin 3 Offset',... 
    'Bin 4 Bsl Offset', 'Bin 4 Offset', 'Bin 5 Bsl Offset', 'Bin 5 Offset', 'Bin 6 Bsl Offset', 'Bin 6 Offset', 'Bin 7 Bsl Offset', 'Bin 7 Offset',... 
   'Bin 8 Bsl Offset', 'Bin 8 Offset', 'Bin 9 Bsl Offset', 'Bin 9 Offset', 'Bin 10 Bsl Offset', 'Bin 10 Offset'};
writematrix('Time', filename, 'Sheet', sheetname, 'Range', 'A1');
writematrix(ts1.', filename,'Sheet', sheetname, 'Range', 'A2');
writetable(auc_csoff, filename, 'Sheet', sheetname, 'Range', 'B1');


%% To output Raw 465 + 405 with Z-Scores for first 5 CS's and last 5 CS's

filename = 'GrabeCBv2.0 IL-BLA CS-US N=10 Example Trace whole baseline.xlsx'; %name of file with exported data
alpha=['A';'E';'J';'N';'S'];

for i=1:numAnimals
    sheetname=animalNames{i};
%     for earlycs=1:5
%         headers={'CS'+string(earlycs)+' Z-Score'; 'Raw 465'; 'Raw 405'};
%         writecell(headers.', filename, 'Sheet', sheetname, 'Range', string(alpha(earlycs))+'1');
%         all=[zall_mat(50*(i-1)+earlycs,:); rawf465{i,1}(earlycs,:)-rawf465{i,1}(earlycs,1); rawf405{i,1}(earlycs,:)-rawf405{i,1}(earlycs,1)];
%         writematrix(all.', filename,'Sheet', sheetname, 'Range', string(alpha(earlycs))+'2');
%     end
    for latecs=46:50
        headers={'CS'+string(latecs)+' Z-Score'; 'Raw 465'; 'Raw 405'};
        writecell(headers.', filename, 'Sheet', sheetname, 'Range', string(alpha(latecs-45))+'1');
        all=[zall_mat(50*(i-1)+latecs,:); rawf465{i,1}(latecs,:)-rawf465{i,1}(latecs,1); rawf405{i,1}(latecs,:)-rawf405{i,1}(latecs,1)];
        writematrix(all.', filename,'Sheet', sheetname, 'Range', string(alpha(latecs-45))+'2');
    end
end

%% To make video traces for binned traces

timestep = 100; % Smaller number = higher resolution data and video

% % CS onset
% ws = -5; % desired window start
% we = 30; % desired window end
% vid_start=find(ts1<-4.4 & ts1>=-5,1);
% vid_stop=find(ts1<30 & ts1>=29.5,1);

% % CS offset
ws = 25; % desired window start
we = 60; % desired window end
vid_start=find(ts1<25.1 & ts1>=24.5,1);
vid_stop=find(ts1<60 & ts1>=59.5,1);

wt = we-ws; % range of window

ts1_vid=ts1(:,vid_start:vid_stop).';


% % % for individual CS onset
% z_CS1_onset = zall_mat(1,:);
% z_vid = z_CS1_onset(:,vid_start:vid_stop).';

% for CS Onset bins
% z_vid=z_bin{1,1}(:,vid_start:vid_stop).';


% for individual CS offset
% z_CS1_offset = zBL4ITI_mat(1,:);
% z_vid = z_CS1_offset(:,vid_start:vid_stop).';

% for CS offset bins
z_vid=z_bin_nBL{1,1}(:,vid_start:vid_stop).';


f_idx = 1;
wd_idx = 1;

% pellet window

viewstart = 1; %start
viewend = length(ts1_vid); %end
wlength = viewend - viewstart; %window length

tracestep = -200;
tracefactor = 20;
imstep = 0;

for a = 1:length(wlength) %viewend
    figure(6)
    hold on;
    curve = animatedline('LineWidth',1,'Color','w');
    curve2 = animatedline('LineWidth',1,'Color','c');
    stepup = 0;
%     enttxt1 = text(0,entrystep-75,'Head','color','c','VerticalAlignment','bottom');
%     enttxt2 = text(0,entrystep-75,'Entry','color','c','VerticalAlignment','top');
%     cuetxt1 = text(SP,entrystep-75,'Light','color','r','VerticalAlignment','bottom','HorizontalAlignment','center');
%     cuetxt2 = text(SP,entrystep-75,'Cue','color','r','VerticalAlignment','top','HorizontalAlignment','center');
    line([ws+0.5 ws+0.5],[-5 -4]*tracefactor+tracestep,'Color','r','LineWidth',3); % scale bar for Z-score
    line([ws+1.2 ws+2.2],[-5 -5]*tracefactor+tracestep,'Color','w','LineWidth',3); % scale bar for time
    lejtxt_sec = text(ws+1.7,-5.3*tracefactor+tracestep,'1 sec','color','w','VerticalAlignment','top','HorizontalAlignment','center');
    lejtxt_Z = text(ws-0.9,-4*tracefactor+tracestep,'Z=1','color','r','VerticalAlignment','top','HorizontalAlignment','center');

    for idx = viewstart(a):viewend(a)
        figure(6)
        hold on
        set(gca,'XLim',[ts1_vid(1) ts1_vid(end)],'YLim',[tracestep*2 100],'FontSmoothing', 'off');
        set(gcf,'Position',[680   354   560   624],'color','k'); %680   354   560   624
%         frame = ceil((idx+(clip*fsg1)-1)/nspf);
%         frame1 = read(obj1,frame);
%         J = imtranslate(flipud(frame1), [0 -imstep], 'FillValues',255,'OutputView','full');
%         image(J)
        axis off
        idx = idx-viewstart(a)+1;
        addpoints(curve,ts1_vid(idx),(z_vid(idx,a)*tracefactor)+tracestep);
        drawnow
        figure(6)
        F(f_idx) = getframe(gcf);
        stepup = stepup + timestep;
        f_idx = f_idx + 1;
    end
%     delete(lejtxt)

    plot(ts1_vid,(z_vid(:,1:wd_idx)*tracefactor)+tracestep, 'Color','w');
    clearpoints(curve)
    clearpoints(curve2)
    wd_idx = wd_idx + 1;
end

%% 

if ws==-5
    video = VideoWriter([animalName, '_', hi_lo, '_', 'Early CS Onset_', 'MPEG-4']); %datestr(now,'HHMMSS''.avi')%['pletdrop',num2str(pletno(1)),'_', filename(end-9:end),'.avi']
else
    video = VideoWriter([animalName, '_', hi_lo, '_', 'Early CS Offset_', 'MPEG-4']); %datestr(now,'HHMMSS''.avi')%['pletdrop',num2str(pletno(1)),'_', filename(end-9:end),'.avi']
end
video.FrameRate = ceil(fsg1/timestep);
video.Quality = 100;
open(video)
writeVideo(video,F)
close(video)