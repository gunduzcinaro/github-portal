
%% CREATE TABLE WITH ANIMAL INFO
%collect all animal names and blockpaths from user, label blockpaths with

animalNames={
'C27099';
'C27100';
'C27101';
'C27102';
'C27103';
'C27104';
'C27105';
'C27092';
'C27093';
'C27094';
'C27095';
'C27096';
'C27097';
'C27098';
};

numAnimals=numel(animalNames);

%% IMPORT AND SORT DATA FROM BORIS CSV OUTPUT
%import data from CSV files from Boris with labeled behavior

blockpaths_boris = {
'C27099L1_Day3';...
'C27100L1_Day3';...
'C27101L3_Day3';...
'C27102L1_Day3';...
'C27103L3_Day3';...
'C27104L1_Day3';...
'C27105L3_Day3';...
'C27092R1_Day3';...
'C27093R3_Day3';...
'C27094R1_Day3';...
'C27095R3_Day3';...
'C27096R1_Day3';...
'C27097R3_Day3';...
'C27098R1_Day3';...
};

%organize time stamps based on Approach, Retrieve, Eat 
for num=1:numAnimals
    boris = readtable(blockpaths_boris{num}, 'NumHeaderLines',16,'Delimiter',',');
    start = find(strcmpi(boris{:,6}, 'Start'));
    
    approachbsl{num,1} = boris{strcmpi(boris{1:start, 6}, 'Approach'),1}; %Approach Baseline time points
    app_ind = find(strcmpi(boris{start:end, 6}, 'Approach')) + start-1; %get index for approach time points
    approach{num,1} = boris{app_ind, 1}; %Approach time points
    eat{num,1}= boris{strcmpi(boris{:,6}, 'Eat'),1}; %Eat time points
end

%% Export data to Excel for plotting in Prism

filename = 'CRISPR IL-BLA Females Num Events.xlsx'; %name file with exported data

numevents=table(animalNames,cellfun(@numel,approachbsl),cellfun(@numel, approach),cellfun(@numel,eat));
Headers={'Mouse ID', 'Approach Baseline', 'Approach', 'Eat'};
numevents.Properties.VariableNames(1:4)=cellstr(Headers);

writetable(numevents, filename, 'Sheet', 'Day 3 Batch 2', 'Range', 'A1')
