
%% CREATE TABLE WITH ANIMAL INFO
%collect all animal names and blockpaths from user, label blockpaths with

animalNames={'B68334A';...
'B68333B';...
'B68336A';...
'B68335B';...
'B68339A';...
'B68341B';...
'B68340A';...
'B68345B';...
};
blockpaths={'\\156.40.185.30\labdata5\LBSG\Maya Xia\Grab ecb\Food Retrieval\GrabeCBv2.0\Day 3\B68334A_B68333B-210727-164214'...
'\\156.40.185.30\labdata5\LBSG\Maya Xia\Grab ecb\Food Retrieval\GrabeCBv2.0\Day 3\B68334A_B68333B-210727-164214'...
'\\156.40.185.30\labdata5\LBSG\Maya Xia\Grab ecb\Food Retrieval\GrabeCBv2.0\Day 3\B68336A_B68335B-210727-160236'...
'\\156.40.185.30\labdata5\LBSG\Maya Xia\Grab ecb\Food Retrieval\GrabeCBv2.0\Day 3\B68336A_B68335B-210727-160236'...
'\\156.40.185.30\labdata5\LBSG\Maya Xia\Grab ecb\Food Retrieval\GrabeCBv2.0\Day 3\B68339A_B68341B-210827-170524'...
'\\156.40.185.30\labdata5\LBSG\Maya Xia\Grab ecb\Food Retrieval\GrabeCBv2.0\Day 3\B68339A_B68341B-210827-170524'...
'\\156.40.185.30\labdata5\LBSG\Maya Xia\Grab ecb\Food Retrieval\GrabeCBv2.0\Day 3\B68340A_B68345B-210727-172309'...
'\\156.40.185.30\labdata5\LBSG\Maya Xia\Grab ecb\Food Retrieval\GrabeCBv2.0\Day 3\B68340A_B68345B-210727-172309'...
};
whichStreams = [34;12;34;12;34;12;34;12];

% AUC Time ranges- set according to time periods of interest
aucbsl_times=[-5 0]; auc_times=[0 5];

numAnimals=numel(animalNames);
dataStruct_names=animalNames;
startTime=zeros(1,numAnimals);
Channel_405_name=animalNames;
Channel_465_name=animalNames;

%make table with all animal info
Table=table(animalNames,blockpaths',dataStruct_names,startTime',Channel_405_name,Channel_465_name,whichStreams);
Headers={'animalNames','blockpath','dataStruct_names','startTime','Channel_405_name','Channel_465_name','whichStreams'};
Table.Properties.VariableNames([1:7])=Headers;

%% IMPORT AND SORT DATA FROM BORIS CSV OUTPUT
%import data from CSV files from Boris with labeled behavior

%add folder with csv files to path
blockpaths_boris = {'B68334A_Day3';...
                    'B68333B_Day3';...
                    'B68336A_Day3';...
                    'B68335B_Day3';...
                    'B68339A_Day3';...
                    'B68341B_Day3';...
                    'B68340A_Day3';...
                    'B68345B_Day3';...
                    };

%organize time stamps based on Approach, Retrieve, Eat 
for num=1:numAnimals
    boris = readtable(blockpaths_boris{num}, 'NumHeaderLines',16,'Delimiter',',');
    start = find(strcmpi(boris{:,6}, 'Start'));
    
    approachbsl{num,1} = boris{strcmpi(boris{1:start, 6}, 'Approach'),1}; %Approach Baseline time points
    app_ind = find(strcmpi(boris{start:end, 6}, 'Approach')) + start-1; %get index for approach time points
    approach{num,1} = boris{app_ind, 1}; %Approach time points
    retrieve{num,1}= boris{strcmpi(boris{:,6}, 'Retrieve'),1}; %Retrieve time points
    eat{num,1}= boris{strcmpi(boris{:,6}, 'Eat'),1}; %Eat time points
end

%% RUN TDTBIN2MAT
%run TDTbin2mat on all of these, fill in the table, and store the datastructures in workspace
%for each animal

zAppbsl={}; zApp={}; zRet={}; zEat={}; zminCols=0; numAppBsl=0;
for aaa=1:numAnimals
    animalName=Table.animalNames{aaa};
    blockpath=Table.blockpath{aaa};
    whichStreams=Table.whichStreams(aaa);
    
    appbsl_data = approachbsl{aaa};
    if ~isempty(appbsl_data)
        [zAppbslind,ts1appbsl]=FP_FoodRet_Trial(animalName, blockpath, whichStreams, appbsl_data);
        zAppbsl{aaa,1}=zAppbslind; %store z scores of individual animals in row of zAppbsl corresponding to animal 
    end
    
    app_data = approach{aaa};
    if ~isempty(app_data)
        [zAppind,ts1app]=FP_FoodRet_Trial(animalName, blockpath, whichStreams, app_data);
        zApp{aaa,1}=zAppind; %store z scores of individual animals in row of zApp corresponding to animal 
    end
    
    ret_data = retrieve{aaa};
    if ~isempty(ret_data)
        [zRetind,ts1ret]=FP_FoodRet_Trial(animalName, blockpath, whichStreams, ret_data);
        zRet{aaa,1}=zRetind; %store z scores of individual animals in row of zRet corresponding to animal 
    end
    
    eat_data = eat{aaa};
    if ~isempty(eat_data)
        [zEatind,ts1eat]=FP_FoodRet_Trial(animalName, blockpath, whichStreams, eat_data);
        zEat{aaa,1}=zEatind; %store z scores of individual animals in row of zEat corresponding to animal 
    end
end

%% OPTIONAL- SKIP IF LENGTH OF ARRAYS IS THE SAME FOR ALL EVENTS
%truncates cells if not the same length
minLength = Inf;
for i=1:size(zAppbsl)
    if ~isempty(zAppbsl{i,1})
        minLength=min(minLength, length(zAppbsl{i, 1}));
    end
end
for i=1:size(zAppbsl)
    if ~isempty(zAppbsl{i,1})
        zAppbsl{i, 1} = zAppbsl{i, 1}(:, 1:minLength);
    end
end

minLength = Inf;
for i=1:size(zApp)
    if ~isempty(zApp{i,1})
        minLength=min(minLength, length(zApp{i, 1}));
    end
end
for i=1:size(zApp)
    if ~isempty(zApp{i,1})
        zApp{i, 1} = zApp{i, 1}(:, 1:minLength);
    end
end

minLength = Inf;
for i=1:size(zRet)
    if ~isempty(zRet{i,1})
        minLength=min(minLength, length(zRet{i, 1}));
    end
end
for i=1:size(zRet)
    if ~isempty(zRet{i,1})
        zRet{i, 1} = zRet{i, 1}(:, 1:minLength);
    end
end

minLength = Inf;
for i=1:size(zEat)
    if ~isempty(zEat{i,1})
        minLength=min(minLength, length(zEat{i, 1}));
    end
end
for i=1:size(zEat)
    if ~isempty(zEat{i,1})
        zEat{i, 1} = zEat{i, 1}(:, 1:minLength);
    end
end
%% GET AVG AND SEM FOR ALL ANIMALS COMBINED

%convert to matrix
zappbsl_mat=cell2mat(zAppbsl);

zapp_mat=cell2mat(zApp);

zret_mat=cell2mat(zRet);

zeat_mat=cell2mat(zEat);

%get average and SEM of all animals
zappbsl_mean=mean(zappbsl_mat,1);
sd_zappbsl=std(zappbsl_mat,1);
sem_zappbsl = sd_zappbsl/sqrt(height(zappbsl_mat));

zapp_mean=mean(zapp_mat,1);
sd_zapp=std(zapp_mat,1);
sem_zapp = sd_zapp/sqrt(height(zapp_mat));

zret_mean=mean(zret_mat,1);
sd_zret=std(zret_mat,1);
sem_zret = sd_zret/sqrt(height(zret_mat));

zeat_mean=mean(zeat_mat,1);
sd_zeat=std(zeat_mat,1);
sem_zeat = sd_zeat/sqrt(height(zeat_mat));

%truncate time points based on new lengths
ts1appbsl = ts1appbsl(1:length(zappbsl_mean));
ts1app = ts1app(1:length(zapp_mean));
ts1ret = ts1ret(1:length(zret_mean));
ts1eat = ts1eat(1:length(zeat_mean));

%% GET AVG AND SEM OF Z-SCORE FOR APP, RET, EAT OF EACH INDIVIDUAL ANIMAL

for i=1:numAnimals
    zAppbsl_indmean{i,1}=mean(zAppbsl{i});
    sdzappbsl_indmean{i,1}=std(zAppbsl{i});
    semzappbsl_indmean{i,1} = sdzappbsl_indmean{i,1}/sqrt(height(zAppbsl{i}));

    zApp_indmean{i,1}=mean(zApp{i});
    sdzapp_indmean{i,1}=std(zApp{i});
    semzapp_indmean{i,1} = sdzapp_indmean{i,1}/sqrt(height(zApp{i}));

    zRet_indmean{i,1}=mean(zRet{i});
    sdzret_indmean{i,1}=std(zRet{i});
    semzret_indmean{i,1} = sdzret_indmean{i,1}/sqrt(height(zRet{i}));
    
    zEat_indmean{i,1}=mean(zEat{i});
    sdzeat_indmean{i,1}=std(zEat{i});
    semzeat_indmean{i,1} = sdzeat_indmean{i,1}/sqrt(height(zEat{i}));
end

%% FIGURE 1: AVERAGE OF ALL ANIMALS, APPROACH BASELINE
figure (1)
hold on
a=0;

p1=patch([a a+28 a+28 a], [-8 -8 22 22], [.8 1 1], 'EdgeColor','none');

lo=zappbsl_mean-sem_zappbsl;
hi=zappbsl_mean+sem_zappbsl;
xxx1=[ts1appbsl, ts1appbsl(end:-1:1)];
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[ .8 .8 .8]); hold on;
set(hp1,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on;
set(gca,'Layer','Top')
plot(ts1appbsl,zappbsl_mean);
title('All Animals, All Approach Baseline') %all Approach bins averaged together and baselined to -5s before
xlim([-5 5])
ylim([-8 8])
set(gca,'fontsize',20)

%% FIGURE 2: AVERAGE OF ALL ANIMALS, APPROACH
figure (2)
hold on
a=0;

p1=patch([a a+28 a+28 a], [-8 -8 22 22], [.8 1 1], 'EdgeColor','none');

lo=zapp_mean-sem_zapp;
hi=zapp_mean+sem_zapp;
xxx1=[ts1app, ts1app(end:-1:1)];
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[ .8 .8 .8]); hold on;
set(hp1,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on;
set(gca,'Layer','Top')
plot(ts1app,zapp_mean);
title('All Animals, All Approach') %all Approach bins averaged together and baselined to -5s before
xlim([-5.2 5.2])
ylim([-8 8])
set(gca,'fontsize',20)
%% FIGURE 3: AVERAGE OF ALL ANIMALS, APPROACH BASELINE + APPROACH
figure (3)
hold on
a=0;

p1=patch([a a+28 a+28 a], [-8 -8 22 22], [.8 1 1], 'EdgeColor','none');
set(get(get(p1, 'Annotation'), 'LegendInformation'), 'IconDisplayStyle', 'off' );

lo_ab=zappbsl_mean-sem_zappbsl;
hi_ab=zappbsl_mean+sem_zappbsl;
xxx1_ab=[ts1appbsl, ts1appbsl(end:-1:1)];
yyy1_ab=[lo_ab, hi_ab(end:-1:1)];
hp1_ab= fill(xxx1_ab,yyy1_ab,[ .8 .8 .8]); hold on;
set(hp1_ab,'FaceColor', [ .8 .8 .8],'EdgeColor','none');
set(get(get(hp1_ab, 'Annotation'), 'LegendInformation'), 'IconDisplayStyle', 'off' );

lo=zapp_mean-sem_zapp;
hi=zapp_mean+sem_zapp;
xxx1=[ts1app, ts1app(end:-1:1)];
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[ .8 .8 .8]); hold on;
set(hp1,'FaceColor', [ .8 .8 .8],'EdgeColor','none');
set(get(get(hp1, 'Annotation'), 'LegendInformation'), 'IconDisplayStyle', 'off' );
hold on
set(gca,'Layer','Top')
plot(ts1appbsl,zappbsl_mean, 'r');
hold on
plot(ts1app,zapp_mean, 'm');
legend('App Bsl', 'App', 'Location', 'northwest')
hold off
title('All Animals, Approach Compare') %all Approach bins averaged together and baselined to -5s before, App Baseline vs. App
xlim([-5.2 5.2])
ylim([-2.5 2.5])
set(gca,'fontsize',20)

%% FIGURE 4: AVERAGE OF ALL ANIMALS, RETRIEVE
figure (4)
hold on
a=0;

p1=patch([a a+28 a+28 a], [-8 -8 22 22], [.8 1 1], 'EdgeColor','none');

lo=zret_mean-sem_zret;
hi=zret_mean+sem_zret;
xxx1=[ts1ret, ts1ret(end:-1:1)];
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[ .8 .8 .8]); hold on;
set(hp1,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on;
set(gca,'Layer','Top')
plot(ts1ret,zret_mean);
title('All Animals, All Retreive') %all Retrieve bins averaged together and baselined to -5s before
xlim([-5.2 5.2])
ylim([-2.5 2.5])
set(gca,'fontsize',20)

%% FIGURE 5: AVERAGE OF ALL ANIMALS, EAT
figure (5)
hold on
a=0;

p1=patch([a a+28 a+28 a], [-8 -8 22 22], [.8 1 1], 'EdgeColor','none');

lo=zeat_mean-sem_zeat;
hi=zeat_mean+sem_zeat;

xxx1=[ts1eat, ts1eat(end:-1:1)];
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[ .8 .8 .8]); hold on;
set(hp1,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on;
set(gca,'Layer','Top')
plot(ts1eat,zeat_mean);
title('All Animals, All Eat') %all CSs bins averaged together and baselined to -5s before
xlim([-5.2 5.2])
ylim([-2.5 2.5])
set(gca,'fontsize',20)

%% AUC FOR APPROACH BASELINE
%zappbsl_mat
AUC_appbsl=[];
for qq = 1:size(zappbsl_mat,1) %qq = 2:3:size(zappbsl_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC_appbsl(qq,1)=trapz(zappbsl_mat(qq,ts1appbsl(1,:) >= aucbsl_times(1) & ts1appbsl(1,:) < aucbsl_times(2)));
    AUC_appbsl(qq,2)=trapz(zappbsl_mat(qq,ts1appbsl(1,:) > auc_times(1) & ts1appbsl(1,:) <= auc_times(2)));
    qq=qq+1;
end

% time normalized AUC
AUC_appbsltn=[AUC_appbsl(:,1)/(aucbsl_times(2)-aucbsl_times(1)) AUC_appbsl(:,2)/(auc_times(2)-auc_times(1))];

AUC_appbsl_mean = mean(AUC_appbsl); %calculate mean ignoring NaNs
AUC_appbsl_SEM = std(AUC_appbsl)/sqrt(numel(AUC_appbsl(:,1))); %calculate SEM without NaNs

% AUC split out per animal
AUCind_appbsl=[];
for i=1:numAnimals
    AUCind_appbsl(i,1)=trapz(zAppbsl_indmean{i}(ts1appbsl(1,:) >= aucbsl_times(1) & ts1appbsl(1,:) < aucbsl_times(2)));
    AUCind_appbsl(i,2)=trapz(zAppbsl_indmean{i}(ts1appbsl(1,:) > auc_times(1) & ts1appbsl(1,:) <= auc_times(2)));
end

% time normalized AUC
AUCind_appbsltn=[AUCind_appbsl(:,1)/(aucbsl_times(2)-aucbsl_times(1)) AUCind_appbsl(:,2)/(auc_times(2)-auc_times(1))];

%% AUC for Approach
%zapp_mat
AUC_app=[];
for qq = 1:size(zapp_mat,1) %qq = 2:3:size(zapp_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC_app(qq,1)=trapz(zapp_mat(qq,ts1app(1,:) >= aucbsl_times(1) & ts1app(1,:) < aucbsl_times(2)));
    AUC_app(qq,2)=trapz(zapp_mat(qq,ts1app(1,:) > auc_times(1) & ts1app(1,:) <= auc_times(2)));
    qq=qq+1;
end

% time normalized AUC
AUC_apptn=[AUC_app(:,1)/(aucbsl_times(2)-aucbsl_times(1)) AUC_app(:,2)/(auc_times(2)-auc_times(1))];

AUC_app_mean = mean(AUC_app); %calculate mean ignoring NaNs
AUC_app_SEM = std(AUC_app)/sqrt(numel(AUC_app(:,1))); %calculate SEM without NaNs

% AUC split out per animal
AUCind_app=[];
for i=1:numAnimals
    AUCind_app(i,1)=trapz(zApp_indmean{i}(ts1app(1,:) >= aucbsl_times(1) & ts1app(1,:) < aucbsl_times(2)));
    AUCind_app(i,2)=trapz(zApp_indmean{i}(ts1app(1,:) > auc_times(1) & ts1app(1,:) <= auc_times(2)));
end

% time normalized AUC
AUCind_apptn=[AUCind_app(:,1)/(aucbsl_times(2)-aucbsl_times(1)) AUCind_app(:,2)/(auc_times(2)-auc_times(1))];

%% AUC for Retrieve
%zret_mat
AUC_ret=[];
for qq = 1:size(zret_mat,1) %qq = 2:3:size(zret_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC_ret(qq,1)=trapz(zret_mat(qq,ts1ret(1,:) >= aucbsl_times(1) & ts1ret(1,:) < aucbsl_times(2)));
    AUC_ret(qq,2)=trapz(zret_mat(qq,ts1ret(1,:) > auc_times(1) & ts1ret(1,:) <= auc_times(2)));
    qq=qq+1;
end

% time normalized AUC
AUC_rettn=[AUC_ret(:,1)/(aucbsl_times(2)-aucbsl_times(1)) AUC_ret(:,2)/(auc_times(2)-auc_times(1))];

AUC_ret_mean = mean(AUC_ret); %calculate mean ignoring NaNs
AUC_ret_SEM = std(AUC_ret)/sqrt(numel(AUC_ret(:,1))); %calculate SEM without NaNs

% AUC split out per animal
AUCind_ret=[];
for i=1:numAnimals
    AUCind_ret(i,1)=trapz(zRet_indmean{i}(ts1ret(1,:) >= aucbsl_times(1) & ts1ret(1,:) < aucbsl_times(2)));
    AUCind_ret(i,2)=trapz(zRet_indmean{i}(ts1ret(1,:) > auc_times(1) & ts1ret(1,:) <= auc_times(2)));
end

% time normalized AUC
AUCind_rettn=[AUCind_ret(:,1)/(aucbsl_times(2)-aucbsl_times(1)) AUCind_ret(:,2)/(auc_times(2)-auc_times(1))];

%% AUC for Eat
%zeat_mat
AUC_eat=[];
for qq = 1:size(zeat_mat,1) %qq = 2:3:size(zeat_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC_eat(qq,1)=trapz(zeat_mat(qq,ts1eat(1,:) >= aucbsl_times(1) & ts1eat(1,:) < aucbsl_times(2)));
    AUC_eat(qq,2)=trapz(zeat_mat(qq,ts1eat(1,:) > auc_times(1) & ts1eat(1,:) <= auc_times(2)));
    qq=qq+1;
end

% time normalized AUC
AUC_eattn=[AUC_eat(:,1)/(aucbsl_times(2)-aucbsl_times(1)) AUC_eat(:,2)/(auc_times(2)-auc_times(1))];

AUC_eat_mean = mean(AUC_eat); %calculate mean ignoring NaNs
AUC_eat_SEM = std(AUC_eat)/sqrt(numel(AUC_eat(:,1))); %calculate SEM without NaNs

% AUC split out per animal
AUCind_eat=[];
for i=1:numAnimals
    AUCind_eat(i,1)=trapz(zEat_indmean{i}(ts1eat(1,:) >= aucbsl_times(1) & ts1eat(1,:) < aucbsl_times(2)));
    AUCind_eat(i,2)=trapz(zEat_indmean{i}(ts1eat(1,:) > auc_times(1) & ts1eat(1,:) <= auc_times(2)));
end

% time normalized AUC
AUCind_eattn=[AUCind_eat(:,1)/(aucbsl_times(2)-aucbsl_times(1)) AUCind_eat(:,2)/(auc_times(2)-auc_times(1))];

%% Export data to Excel for plotting in Prism

filename = 'GRABeCBv2.0 IL-BLA Day 3 N=500.xlsx'; %name file with exported data

% creates table with Z-scores
zscores=table(ts1appbsl.',zappbsl_mean.',sem_zappbsl.',zapp_mean.',sem_zapp.',zret_mean.',sem_zret.',zeat_mean.',sem_zeat.');
Headers={'ts1', 'Z-Score App Bsl', 'SEM App Bsl', 'Z-Score App', 'SEM App', 'Z-Score Ret', 'SEM Ret', 'Z-Score Eat', 'SEM Eat'};
zscores.Properties.VariableNames(1:9)=cellstr(Headers);

% creates table with time normalized AUCs averaged and split by animal
AUC_indtn=table(animalNames,AUCind_appbsltn,AUCind_apptn,AUCind_rettn,AUCind_eattn);
Headers={'Animal ID', 'App Bsl', 'App', 'Ret', 'Eat'};
AUC_indtn.Properties.VariableNames(1:5)=cellstr(Headers);

% creates table with AUCs averaged and split by animal
AUC_ind=table(animalNames,AUCind_appbsl,AUCind_app,AUCind_ret,AUCind_eat);
Headers={'Animal ID', 'App Bsl', 'App', 'Ret', 'Eat'};
AUC_ind.Properties.VariableNames(1:5)=cellstr(Headers);

% writes tables into exported file
writetable(zscores, filename, 'Sheet', 'Z-Scores', 'Range', 'A1')
writetable(AUC_indtn, filename, 'Sheet', 'Time Norm AUC by Mouse', 'Range', 'A1')
writetable(AUC_ind, filename, 'Sheet', 'AUC by Mouse', 'Range', 'A1')

% exports time normalized AUC for all animals together
sheet='Time Norm AUC All';
columns = {'Bsl'; 'App Bsl'; 'Bsl'; 'App'; 'Bsl'; 'Ret'; 'Bsl'; 'Eat'};

writecell(columns.', filename, 'Sheet', sheet, 'Range', 'A1'); %column headers
writematrix(AUC_appbsltn, filename, 'Sheet', sheet, 'Range', 'A2');
writematrix(AUC_apptn, filename, 'Sheet', sheet, 'Range', 'C2');
writematrix(AUC_rettn, filename, 'Sheet', sheet, 'Range', 'E2');
writematrix(AUC_eattn, filename, 'Sheet', sheet, 'Range', 'G2');

% exports AUC for all animals together
sheet='AUC All';
columns = {'Bsl'; 'App Bsl'; 'Bsl'; 'App'; 'Bsl'; 'Ret'; 'Bsl'; 'Eat'};

writecell(columns.', filename, 'Sheet', sheet, 'Range', 'A1'); %column headers
writematrix(AUC_appbsl, filename, 'Sheet', sheet, 'Range', 'A2');
writematrix(AUC_app, filename, 'Sheet', sheet, 'Range', 'C2');
writematrix(AUC_ret, filename, 'Sheet', sheet, 'Range', 'E2');
writematrix(AUC_eat, filename, 'Sheet', sheet, 'Range', 'G2');

%% IMPORT AND SORT DATA FROM ANYMAZE CSV OUTPUT
% 
% blockpaths_csv = {'C17681A_Day1';...
% 'C17682B_Day1';...
% 'C17683A_Day1';...
% 'C17684B_Day1';...
% 'C17685A_Day1';...
% 'C17686B_Day1';...
% 'C17687A_Day1';...
% 'C17688B_Day1';...
% };
% 
% %organize time stamps based on Approach, Retrieve, Eat 
% for num=1:numAnimals
%     if strfind(blockpaths_csv{num},'_Day')
% %         boris = readtable(blockpaths_csv{num}, 'NumHeaderLines',16);
%         boris = readtable(blockpaths_csv{num});
%         start = find(strcmpi(boris{:,6}, 'Start'));
%         approachbsl{num,1} = boris{strcmpi(boris{1:start, 6}, 'Approach'),1}; %Approach Baseline time points
%         app_ind = find(strcmpi(boris{start:end, 6}, 'Approach')) + start-1; %get index for approach time points
%         approach{num,1} = boris{app_ind, 1}; %Approach time points
%         retrieve{num,1}= boris{strcmpi(boris{:,6}, 'Retrieve'),1}; %Retrieve time points
%         eat{num,1}= boris{strcmpi(boris{:,6}, 'Eat'),1}; %Eat time points
%     else
% %         csvfile = readtable(blockpaths_csv{num}, 'NumHeaderLines',1);
%         csvfile = readtable(blockpaths_csv{num});
% 
%         start = find(csvfile{:,5}==1);
%         approachbsl{num,1} = csvfile{:,1}(find(csvfile{1:start,2}==1));
%         approach{num,1} = csvfile{:,1}(find(csvfile{start:end,2}==1)+start-1);
%         retrieve{num,1}= csvfile{:,1}(find(csvfile{:,3}==1));
%         eat{num,1}= csvfile{:,1}(find(csvfile{:,4}==1));
%     end
% end