
%collect all animal names and blockpaths from user, label blockpaths with

animalNames={'C34016A';...
'C34017B';...
};

blockpaths={
'Z:\Elise Van Leer\GRABeCBv2.7 IL-BLA\Fear\Tanks\Ren\C34016_C34017-230609-131713'...
'Z:\Elise Van Leer\GRABeCBv2.7 IL-BLA\Fear\Tanks\Ren\C34016_C34017-230609-131713'...
};
whichStreams=[34;12];

%AUC time ranges
csonbsl_auc=[-5 0]; cson_auc=[0 30]; csoffbsl_auc=[25 30]; csoff_auc=[30 60];

TRANGE = [-5 65]; %  window size [start time relative to epoc onset, window duration]
BSL_PER = [-5 0]; % baseline period within our window
BSL_ITI_PER = [25 30];
N = 500;

numAnimals=numel(animalNames);
dataStruct_names=animalNames;
startTime=zeros(1,numAnimals);
Channel_405_name=animalNames;
Channel_465_name=animalNames;

%make table with all animal info

Table=table(animalNames,blockpaths',dataStruct_names,startTime',Channel_405_name,Channel_465_name,whichStreams);
Headers={'animalNames','blockpath','dataStruct_names','startTime','Channel_405_name','Channel_465_name','whichStreams'};
Table.Properties.VariableNames([1:7])=Headers;
% %fill in animal names

%%

%run TDTbin2mat on all of these, fill in the table, and store the datastructures in workspace
%for each animal....
zAll={}; minCols=0;
for aaa=1:numAnimals
    animalName=Table.animalNames{aaa};
    blockpath=Table.blockpath{aaa};
    whichStreams=Table.whichStreams(aaa);
        
    [zAllind, zerr,ts1,zBL4ITI]=FP_ret_analysis_with30sITI_streams_epocTTL_corr_JS(animalName,blockpath,whichStreams,aaa,TRANGE,BSL_PER,BSL_ITI_PER,N);
    zAll{aaa,1}=zAllind; %store z scores of individual animals in row of ZAll corresponding to animal 
    zBL4ITI_all{aaa,1}=zBL4ITI;
    
end
%%
%CONVERT TO MATRIX  - initially store in cell just in case data from dif
%files for some reason aren't the same length. If they aren't, code will
%error here but you won't lose zAll in cell array form
zall_mat=cell2mat(zAll);
clear zAll %clear zall_all to save space
    
zBL4ITI_mat=cell2mat(zBL4ITI_all);
clear zBL4ITI_all %clear zall_all to save space

%GET AVERAGE ACROSS ALL ANIMALS, ALL CSs (basically assumes that all
%CSs is equal, and doesn't care which animal contributes which trial
zall_mean=mean(zall_mat,1);
sd_zall=std(zall_mat,1);

%%
%FIGURE 1: AVERAGE OF ALL ANIMALS, ALL CSs
%just looking at whole average before breaking down into bins...
figure (1)
hold on
a=0;

p1=patch([a a+28 a+28 a], [-8 -8 8 8], [.8 1 1], 'EdgeColor','none');
p4=patch([a+28 a+30 a+30 a+28], [-8 -8 8 8], [1 .8 .8], 'EdgeColor','none');


lo=zall_mean-sd_zall;
hi=zall_mean+sd_zall;
xxx1=[ts1, ts1(end:-1:1)];
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[ .8 .8 .8]); hold on;
set(hp1,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on;
set(gca,'Layer','Top')
plot(ts1,zall_mean);
title('All Animals, All CSs')
set(gca,'fontsize',20)
%%
%BINS: Now, we'll organize data into bins. For now, we'll do bins of 5 CSs
%per bin

z_bin5={};first5={};last5={};z_bin_nBL={};
bin_size=5; %modify this to change how many CSs per bin
CStot=5; %enter total number of CSs - you can have matlab look for this, but for now I'm just hard coding this value assuming ext is always 30 CSs
num_bins=CStot/bin_size;


for bin = 1:num_bins
    %set bin
    a=bin_size*(bin-1)+1;
    z_this_bin=[];z_this_bin_nBL=[];
    %locate animal and compile first [bin size] for each animal
    for mouse=1:numAnimals
        
        start=5*(mouse-1);%this assumes there are 5 CSs per animal (which should be true, but careful if you change protocol)
        start=start+a; fin=start+4;% number must be bin-1
        z_this_bin= [z_this_bin; zall_mat(start:fin,:)];
        z_this_bin_nBL=[z_this_bin_nBL; zBL4ITI_mat(start:fin,:)];
     
        if bin==1
            zCS1(mouse,:)=zall_mat(start,:);
            first5{mouse,1}=mean(zall_mat(start:fin,:),1); %average of first five CSs for each mouse (each mouse is one row)
            zs_bin1=z_this_bin; %will be helpful if you later need to exclude
            zs_bin1_nBL=z_this_bin_nBL; %will be helpful if you later need to exclude
      
        elseif bin ==num_bins
            last5{mouse,1}=mean(zall_mat(start:fin,:),1);%average of last five CSs for each mouse (each mouse is one row)
            zs_bin10=z_this_bin;%will be helpful if you later need to exclude
            zs_bin10_nBL=z_this_bin_nBL;
            
        end
        
        
    end
    
    
    %average across animals
    
    %Below will use each animal's data to find mean for each bin and SEM
    %across animals for that particular bin
    z_bin{bin,1}=mean(z_this_bin,1);
    bin_sd{bin,1}=(std(z_this_bin,1))./((numel(z_this_bin(:,1)))^.5);% sd is actually SEM as of 10/24/2019
    z_bin_nBL{bin,1}=mean(z_this_bin_nBL,1);
    bin_sd_nBL{bin,1}=(std(z_this_bin_nBL,1))./((numel(z_this_bin_nBL(:,1)))^.5);% sd is actually SEM as of 10/24/2019
end

%%
%Figure 2: First 5 CSs
%short traces

figure (2)
hold on
plot([0;0],[-20; 20],'--','color',[.8 .8 .8],'LineWidth',2);


%SD bin 1
lo=z_bin{1,1}-bin_sd{1,1};
hi=z_bin{1,1}+bin_sd{1,1};
% lo=mean_zbin1_ex-bin1_ex_sd;
% hi=mean_zbin1_ex+bin1_ex_sd;
xxx1=[ts1, ts1(end:-1:1)];%used to be ts1_all{1,:} instead of ts1? maybe related to OFL analysis
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[.96 .47 .49],'facealpha',.5); hold on; %old green was 0 .5 .1
set(hp1,'FaceColor', [.96 .47 .49],'EdgeColor','none');hold on;


% 
% %SD bin 10
% lo=z_bin{10,1}-bin_sd{10,1};
% hi=z_bin{10,1}+bin_sd{10,1};
% xxx1=[ts1_all{1,:}, ts1_all{1,:}(end:-1:1)];
% yyy1=[lo, hi(end:-1:1)];
% hp1= fill(xxx1,yyy1,[.56 .02 .03],'facealpha',.5); hold on;
% set(hp1,'FaceColor', [.56 .02 .03],'EdgeColor','none');hold on;



% p1to3=plot(ts1,mean_zbin1_ex,'color',[.96 .47 .49],'LineWidth',2);
p1to5=plot(ts1,z_bin{1,1},'color',[.96 .47 .49],'LineWidth',2); hold on; %light red


%add scale bar
% plot([-8; -7], [0;0],'-k', [0; 0], [7;8],'k', 'LineWidth',2);

% text(-4.2, -1.5, 'z=1', 'HorizontalAlignment','right');
% text(-3.5, -2.5, '1 s', 'HorizontalAlignment','center');
% set(gca, 'XTick',[],'XTickLabel',[],'xcolor',[1 1 1]);

title('CS Onset') %Av Fisrt 5 CS bin
xlabel('Time(s)')
ylabel('Z-Score')
xlim([-5.5 30.5])
ylim([-2 4])
set(gca,'fontsize',20)

%%
%Looking at ITI 
%Here, we'll baseline to t=25 to t=30 (taking t=0 to be CS onset)



%Figure 3: First 5 ITIs
%short traces

figure (4)
hold on
plot([30;30],[-20; 20],'--','color',[.8 .8 .8],'LineWidth',2);


%SD bin 1
lo=z_bin_nBL{1,1}-bin_sd_nBL{1,1};
hi=z_bin_nBL{1,1}+bin_sd_nBL{1,1};
% lo=mean_zbin1_ex-bin1_ex_sd;
% hi=mean_zbin1_ex+bin1_ex_sd;
xxx1=[ts1, ts1(end:-1:1)];%used to be ts1_all{1,:} instead of ts1? maybe related to OFL analysis
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[.96 .47 .49],'facealpha',.5); hold on; %old green was 0 .5 .1
set(hp1,'FaceColor', [.96 .47 .49],'EdgeColor','none');hold on;


% 
% %SD bin 10
% lo=z_bin{10,1}-bin_sd{10,1};
% hi=z_bin{10,1}+bin_sd{10,1};
% xxx1=[ts1_all{1,:}, ts1_all{1,:}(end:-1:1)];
% yyy1=[lo, hi(end:-1:1)];
% hp1= fill(xxx1,yyy1,[.56 .02 .03],'facealpha',.5); hold on;
% set(hp1,'FaceColor', [.56 .02 .03],'EdgeColor','none');hold on;



% p1to3=plot(ts1,mean_zbin1_ex,'color',[.96 .47 .49],'LineWidth',2);
p1to5=plot(ts1,z_bin_nBL{1,1},'color',[.96 .47 .49],'LineWidth',2); hold on; %light red


%add scale bar
% plot([-8; -7], [0;0],'-k', [0; 0], [7;8],'k', 'LineWidth',2);

% text(-4.2, -1.5, 'z=1', 'HorizontalAlignment','right');
% text(-3.5, -2.5, '1 s', 'HorizontalAlignment','center');
% set(gca, 'XTick',[],'XTickLabel',[],'xcolor',[1 1 1]);

xlim([24.5 60.5])
ylim([-2 4])
title('CS Offset') %Av First 5 ITI bin
xlabel('Time(s)')
ylabel('Z-Score')
set(gca,'fontsize',20)

%%
%zall_mat (CS)
AUC=[]; % cue, shock
for qq = 1:size(zall_mat,1) %qq = 2:3:size(zall_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip== 1st 50 is mouse 1
    AUC(qq,1)=trapz(zall_mat(qq,ts1(1,:) >= csonbsl_auc(1) & ts1(1,:) < csonbsl_auc(2))); %baseline
    AUC(qq,2)=trapz(zall_mat(qq,ts1(1,:) >cson_auc(1) & ts1(1,:) < cson_auc(2))); %CS onset
    qq=qq+1;
end
AUC_mean = nanmean(AUC); %calculate mean ignoring NaNs
AUC_SEM = nanstd(AUC)/sqrt(numel(AUC(:,1))); %calculate SEM without NaNs

%%
%zBL4ITI_mat (ITI)

for qq = 1:size(zBL4ITI_mat,1) %qq = 2:3:size(zBL4ITI_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC(qq,3)=trapz(zBL4ITI_mat(qq,ts1(1,:) >csoffbsl_auc(1) & ts1(1,:) < csoffbsl_auc(2))); %CS offset baseline
    AUC(qq,4)=trapz(zBL4ITI_mat(qq,ts1(1,:) >csoff_auc(1) & ts1(1,:) < csoff_auc(2))); %CS offset
    qq=qq+1;
end
AUC_mean = nanmean(AUC); %calculate mean ignoring NaNs
AUC_SEM = nanstd(AUC)/sqrt(numel(AUC(:,1))); %calculate SEM without NaNs

%%
% average AUC per animal
indAUC_avg=[];

for i=1:numAnimals
    for n=1:size(AUC,2)
        indAUC_avg(i,n)=mean(AUC(i*5-4:i*5,n));
    end
end

%%
%export to excel
filename = 'GRAB eCBv2.7 IL-BLA CS-US Late Ren n=2 N=500.xlsx'; %name file with exported data

num_CS = 5;
num_el = 1:numAnimals*num_CS;
mouse_num = ones(num_CS*numAnimals, 1);
animal_name = {};
for num=1:numAnimals
    for n=1:num_CS
        animal_name{end+1}= animalNames{num};
    end
end
CS_num = [];
for num=1:numAnimals
    mouse_num(num_CS*num-(num_CS-1):num_CS*num)=num;
    CS_num=[CS_num 1:num_CS];
end

sheetname = 'Z-Scores';

zscores=table(ts1.',z_bin{1,1}.',bin_sd{1,1}.',z_bin_nBL{1,1}.',bin_sd_nBL{1,1}.');
Headers={'ts1', 'Z-Score CS Onset', 'SEM CS Onset', 'Z-Score CS Offset', 'SEM CS Offset'};
zscores.Properties.VariableNames(1:5)=cellstr(Headers);

writetable(zscores, filename, 'Sheet', sheetname, 'Range', 'A1');

sheetname = 'Time Norm AUC';

csonbsltime=csonbsl_auc(2)-csonbsl_auc(1);
csontime=cson_auc(2)-cson_auc(1);
csoffbsltime=csoffbsl_auc(2)-csoffbsl_auc(1);
csofftime=csoff_auc(2)-csoff_auc(1);

indAUCtn_avg=[];
indAUCtn_avg(:,1)=indAUC_avg(:,1)/csonbsltime;
indAUCtn_avg(:,2)=indAUC_avg(:,2)/csontime;
indAUCtn_avg(:,3)=indAUC_avg(:,3)/csoffbsltime;
indAUCtn_avg(:,4)=indAUC_avg(:,4)/csofftime;

timenormauc=table(num_el(:),mouse_num,animal_name.',CS_num(:),AUC(:,1)/csonbsltime,AUC(:,2)/csontime,AUC(:,3)/csoffbsltime,AUC(:,4)/csofftime);
Headers={'#', 'Mouse #', 'Mouse ID', 'CS #', 'CS Onset Pre', 'CS Onset Post', 'CS Offset Pre', 'CS Offset Post'};
timenormauc.Properties.VariableNames(1:8)=cellstr(Headers);

writetable(timenormauc, filename, 'Sheet', sheetname, 'Range', 'A1');

sheetname = 'Time Norm AUC Per Animal';

tnauc_ind=table(animalNames, indAUCtn_avg(:,1),indAUCtn_avg(:,2),indAUCtn_avg(:,3),indAUCtn_avg(:,4));
headers={'Mouse ID', 'CS On Bsl', 'CS On', 'CS Off Bsl', 'CS Off'};
tnauc_ind.Properties.VariableNames(1:5)=cellstr(headers);

writetable(tnauc_ind, filename, 'Sheet', sheetname, 'Range', 'A1');

sheetname = 'AUC Ret';

auc_cond=table(num_el(:),mouse_num,animal_name.',CS_num(:),AUC(:,1),AUC(:,2),AUC(:,3),AUC(:,4));
Headers={'#', 'Mouse #', 'Mouse ID', 'CS #', 'AUC '+string(csonbsl_auc(1))+'-'+string(csonbsl_auc(2)),...
    'AUC '+string(cson_auc(1))+'-'+string(cson_auc(2)), 'AUC '+string(csoffbsl_auc(1))+'-'+string(csoffbsl_auc(2)),... 
    'AUC '+string(csoff_auc(1))+'-'+string(csoff_auc(2))};
auc_cond.Properties.VariableNames(1:8)=cellstr(Headers);

writetable(auc_cond, filename, 'Sheet', sheetname, 'Range', 'A1');