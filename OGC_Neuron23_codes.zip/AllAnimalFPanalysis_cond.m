
%%
%collect all animal names and blockpaths from user, label blockpaths with
%animal name
animalNames={
'C34008A';
'C34009B';
};
blockpaths={'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Cond\C34008A_C34009B-230605-101528'...
'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Cond\C34008A_C34009B-230605-101528'...
};
whichStreams=[34;12];


% adjust time range, baseline period, downsampling rate
TRANGE = [-180 500]; %  window si ze [start time relative to epoc onset, window duration]
BASELINE_PER = [-180 0]; % baseline period within our window
N = 1000;

numAnimals=numel(animalNames);
dataStruct_names=animalNames;
startTime=zeros(1,numAnimals);
Channel_405_name=animalNames;
Channel_465_name=animalNames;

%make table with all animal info

Table=table(animalNames,blockpaths',dataStruct_names,startTime',Channel_405_name,Channel_465_name,whichStreams);
Headers={'animalNames','blockpath','dataStruct_names','startTime','Channel_405_name','Channel_465_name','whichStreams'};
Table.Properties.VariableNames([1:7])=Headers;
% %fill in animal names

%%

%run TDTbin2mat on all of these, fill in the table, and store the datastructures in workspace
%for each animal....

for aaa=1:numAnimals
    animalName=Table.animalNames{aaa};
    blockpath=Table.blockpath{aaa};
    stream=Table.whichStreams(aaa);
    [zAnimalAll,zerrAnimal,ts1,Chan405,Chan465] = FP_cond_analysis_streams(animalName,blockpath,stream,aaa,TRANGE,BASELINE_PER,N);
    %change NEWNAME=zAnimalAll
    Table.Channel_405_name(aaa)={Chan405};
    Table.Channel_465_name(aaa)={Chan465};
    %the correction below will adjust data points according to the first
    %inputed dataset.  This needs to be changed in case later sessions are
    %shorter (rather than longer) than the first.  THis error is only a
    %difference of one value - it's just because of the way the data are
    %truncated.
    if aaa>1 
        if numel(zAnimalAll)> numel(zAll(1,:))
            disp('time vector has one more element')
            newCol=numel(zAll(1,:));
            zAnimalAll=zAnimalAll(1,1:newCol);
        elseif numel(zAnimalAll)<numel(zAll(1,:))
            zAll=zAll(:,1:numel(zAnimalAll));
            ts1=ts1(1:numel(zAll(1,:)));
            disp('time vector has one less element')
        end
    end
    
    zAll(aaa,:)=zAnimalAll;
    Zerr(aaa,:)=zerrAnimal;

end
%%
%make user check table



%collect z scores

%%
[~,cols]=size(zAll);
for ii=1:cols
    zAvg(ii)=mean(zAll(:,ii));
    values=zAll(:,ii);
    stdDev(ii)=std(values);
end

SEM=stdDev./(sqrt(numAnimals));
lo=zAvg-SEM;
hi=zAvg+SEM;

figure(1)
hold on 
% Plot vertical line at epoch onset, time = 0

shadeTop=1.05*(max(hi));
a=0;
b=[0 90 210];
for ii=1:3
    a=b(ii);
    p1=patch([a a+28 a+28 a], [-20 -20 shadeTop shadeTop], [.8 1 1], 'EdgeColor','none');
    p2=patch([a+28 a+30 a+30 a+28],[-20 -20 shadeTop shadeTop], [1 .8 .8],'EdgeColor','none');
   
end 

xxx=[ts1, ts1(end:-1:1)];
yyy=[lo,hi(end:-1:1)];
hp= fill(xxx,yyy,[ .8 .8 .8]);hold on;  
set(hp,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on; 
legend([p1 p2 hp],{'Tone','Shock','SEM'},'Location','northwest')
nn=['Average Z-score, n=' num2str(numAnimals)];
plot(ts1, zAvg, 'k', 'LineWidth', 1,'DisplayName',nn); hold on;

set(gca,'Layer','top')
xlabel('Time(s)')
ylabel('Z-Score')
ylim([-3 5])
xlim([-200 400])
set(gca,'fontsize',20)
% 
%%
%plot second group -comment this all out when you don't want it :)
%xxx=[ts1, ts1(end:-1:1)];
%yyy=[lo,hi(end:-1:1)];
%hp= fill(xxx,yyy,[ 1 .8 .8]); hold on;
%set(hp,'FaceColor', [ 1 .8 .8],'EdgeColor','none');hold on;
%plot(ts1, zAvg, 'color',[.8, 0, 0], 'LineWidth', 1); hold on;
%%

%graph individual traces  on one graph

figure (2)
hold on

coloring=[1 0 0; 1 .4 0; 1 .8 0; 1 1 .2; .6 1 .4;.4 .6 .4; .2 .2 .6; 0 0 .4; .4 0 .4;.8 0 .6; 1 0 .4; .2 1 1; 0 0 0; .7 .7 .7; .8 1 .6; .6 0 0];
a=0;
b=[0 90 210];
shadeTop=1.05*max(max(zAll));
for ii=1:3
    a=b(ii);
    p1=patch([a a+28 a+28 a], [-20 -20 shadeTop shadeTop], [.8 1 1], 'EdgeColor','none');
    p2=patch([a+28 a+30 a+30 a+28],[-20 -20 shadeTop shadeTop], [1 .8 .8],'EdgeColor','none');
   
end 
legend([p1 p2],{'Tone','Shock'},'Location','northwest')

for allTraces=1:numAnimals
    name=Table.animalNames{allTraces};
    plot(ts1, zAll(allTraces,:), 'color',coloring(allTraces,:), 'LineWidth', 1,'DisplayName',name); hold on;
end

set(gca,'Layer','top')

%%
%separate graphs
figure (3)
hold on
for allTraces=1:numAnimals
    subplot(numAnimals, 1, allTraces)
    
    a=0;
    b=[0 90 210];
    shadeTop=1.05*max(zAll(allTraces,:));
    for ii=1:3
        a=b(ii);
        p3=patch([a a+28 a+28 a], [-20 -20 shadeTop shadeTop], [.8 1 1], 'EdgeColor','none');
        p4=patch([a+28 a+30 a+30 a+28],[-20 -20 shadeTop shadeTop], [1 .8 .8],'EdgeColor','none');hold on;
    end
    legend([p3 p4],{'Tone','Shock'},'AutoUpdate','off','Position',[.22,.33,.167,.28])
    legend boxoff


    plot(ts1, zAll(allTraces,:), 'color',coloring(allTraces,:), 'LineWidth', 1); hold on;
    title(animalNames{allTraces})
    if allTraces~=numAnimals
        set(gca,'xtick',[])
    end
    set(gca,'Layer','top')
  set(get(gca,'title'),'Position',[-150,.85*max(zAll(allTraces,:))]); hold on
end
set(gca,'Layer','top')
xlabel('Time(s)')
ylabel('Z-Score')
xlim([-200 400])
ylim([-10 10])
set(gca,'fontsize',20)
