
%% 
%collect all animal names and blockpaths from user, label blockpaths with

animalNames={
'C34008A';
'C34009B';
'C34010A';
'C34011B';
'C34012A';
'C34013B';
'C34014A';
'C34015B';
};
blockpaths={'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Ext\C34008A_C34009B-230606-101545'...
'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Ext\C34008A_C34009B-230606-101545'...
'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Ext\C34010A_C34011B-230606-112504'...
'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Ext\C34010A_C34011B-230606-112504'...
'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Ext\C34012A_C34013B-230606-130459'...
'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Ext\C34012A_C34013B-230606-130459'...
'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Ext\C34014A_C34015B-230606-141120'...
'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Ext\C34014A_C34015B-230606-141120'...
};
whichStreams=[34;12;34;12;34;12;34;12];

TRANGE = [-180 3180]; %  window size [start time relative to epoc onset, window duration]
BASELINE_PER = [-180 0]; % baseline period within our window
N = 1000;

numAnimals=numel(animalNames);
dataStruct_names=animalNames;
startTime=zeros(1,numAnimals);
Channel_405_name=animalNames;
Channel_465_name=animalNames;

%make table with all animal info

Table=table(animalNames,blockpaths',dataStruct_names,startTime',Channel_405_name,Channel_465_name,whichStreams);
Headers={'animalNames','blockpath','dataStruct_names','startTime','Channel_405_name','Channel_465_name','whichStreams'};
Table.Properties.VariableNames([1:7])=Headers;
% %fill in animal names


%%

%run TDTbin2mat on all of these, fill in the table, and store the datastructures in workspace
%for each animal....

for aaa=1:numAnimals
    animalName=Table.animalNames{aaa};
    blockpath=Table.blockpath{aaa};
    whichStreams=Table.whichStreams(aaa);
    [zAnimalAll,zerrAnimal,ts1,Chan405,Chan465] =FP_ext_analysis_streams_30sITI_corrfull(animalName,blockpath,whichStreams,aaa,TRANGE,BASELINE_PER,N);
    %change NEWNAME=zAnimalAll
    Table.Channel_405_name(aaa)={Chan405};
    Table.Channel_465_name(aaa)={Chan465};
    %the correction below will adjust data points according to the first
    %inputed dataset.  This needs to be changed in case later sessions are
    %shorter (rather than longer) than the first.  THis error is only a
    %difference of one value - it's just because of the way the data are
    %truncated.
    if aaa>1 
        if numel(zAnimalAll)> numel(zAll(1,:))
            disp('time vector has one more element')
            newCol=numel(zAll(1,:));
            zAnimalAll=zAnimalAll(1,1:newCol);
            ts1=ts1(1,1:newCol);
        elseif numel(zAnimalAll)<numel(zAll(1,:))
            zAll=zAll(:,1:numel(zAnimalAll));
            ts1=ts1(1:numel(zAll(1,:)));
            disp('time vector has one less element')
        end
    end
    
    zAll(aaa,:)=zAnimalAll;
    Zerr(aaa,:)=zerrAnimal;
    
   
end
%%
%make user check table



%collect z scores

%%
[~,cols]=size(zAll);

for ii=1:cols
    zAvg(ii)=mean(zAll(:,ii));
    values=zAll(:,ii);
    stdDev(ii)=std(values);
end

SEM=stdDev./(sqrt(numAnimals));
lo=zAvg-SEM;
hi=zAvg+SEM;

figure(1)
hold on

% Plot vertical line at epoch onset, time = 0

%for loop for 50 tone extinction

a=0;
for ii=1:50
    p1=patch([a a+30 a+30 a], [-5 -5 20 20], [.8 1 1], 'EdgeColor','none');
   a=a+60;
end 

% for desensitization- first 5 and last 5 tones
%a=0;
%for ii=1:5
 %   p1=patch([a a+30 a+30 a], [-5 -5 20 20], [.8 1 1], 'EdgeColor','none');
  %  a=a+60;
%end 
 
 %a=2700;
 %for ii=1:5
  %   p1=patch([a a+30 a+30 a], [-5 -5 20 20], [.8 1 1], 'EdgeColor','none');
   %  a=a+60;
% end 
xxx=[ts1, ts1(end:-1:1)];
yyy=[lo, hi(end:-1:1)];

hp= fill(xxx,yyy,[ .8 .8 .8]); hold on;
set(hp,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on;
p3=plot(ts1, zAvg, 'k', 'LineWidth', 1,'DisplayName','z-score'); hold on;

legend([p1],{'Tone'},'Location','northwest')

% Make a legend
legend([p1 p3 hp],{'Tone','z-score','SEM'}, 'AutoUpdate', 'off');


set(gca,'Layer','top')
xlabel('Time(s)')
ylabel('Z-Score')
set(gca,'fontsize',20)
ylim([-5 5])

%%
AUC={};
per_on=[-60	0	30	60	90	120	150	180	210	240	270	300	330	360	390	420	450	480	510	540	570	600	630	660	690	720	750	780	810	840	870	900	930	960	990	1020	1050	1080	1110	1140	1170	1200	1230	1260	1290	1320	1350	1380	1410	1440	1470	1500	1530	1560	1590	1620	1650	1680	1710	1740	1770	1800	1830	1860	1890	1920	1950	1980	2010	2040	2070	2100	2130	2160	2190	2220	2250	2280	2310	2340	2370	2400	2430	2460	2490	2520	2550	2580	2610	2640	2670	2700	2730	2760	2790	2820	2850	2880	2910	2940	2970	3000	3030	3060
];
per_off=[0	30	60	90	120	150	180	210	240	270	300	330	360	390	420	450	480	510	540	570	600	630	660	690	720	750	780	810	840	870	900	930	960	990	1020	1050	1080	1110	1140	1170	1200	1230	1260	1290	1320	1350	1380	1410	1440	1470	1500	1530	1560	1590	1620	1650	1680	1710	1740	1770	1800	1830	1860	1890	1920	1950	1980	2010	2040	2070	2100	2130	2160	2190	2220	2250	2280	2310	2340	2370	2400	2430	2460	2490	2520	2550	2580	2610	2640	2670	2700	2730	2760	2790	2820	2850	2880	2910	2940	2970	3000	3030	3060	3090
]; 


for mouse=1:numAnimals
    
    for num=1:numel(per_on)
        AUC{mouse,num}=trapz(zAll(mouse,ts1(1,:) < per_off(num) & ts1(1,:) > per_on(num)));
        
    end

end


 %%
  
  
per_CSon=[ 0 60 120 180 240 300	360	420	480	540	600	660	720	780	840	900	960	1020 1080	1140	1200	1260	1320	1380	1440	1500	1560	1620	1680	1740	1800	1860	1920	1980	2040	2100	2160	2220	2280	2340	2400	2460	2520	2580	2640	2700	2760	2820	2880	2940	3000	3060
];
per_CSoff=[ 30	90	150	210	270	330	390	450	510	570	630	690	750	810	870	930	990	1050	1110	1170	1230	1290	1350	1410	1470	1530	1590	1650	1710	1770	1830	1890	1950	2010	2070	2130	2190	2250	2310	2370	2430	2490	2550	2610	2670	2730	2790	2850	2910	2970	3030	3090	3150
];

per_ITIon=[ 30	90	150	210	270	330	390	450	510	570	630	690	750	810	870	930	990	1050	1110	1170	1230	1290	1350	1410	1470	1530	1590	1650	1710	1770	1830	1890	1950	2010	2070	2130	2190	2250	2310	2370	2430	2490	2550	2610	2670	2730	2790	2850	2910	2970	3030];
per_ITIoff=[60 120 180 240 300	360	420	480	540	600	660	720	780	840	900	960	1020 1080	1140	1200	1260	1320	1380	1440	1500	1560	1620	1680	1740	1800	1860	1920	1980	2040	2100	2160	2220	2280	2340	2400	2460	2520	2580	2640	2700	2760	2820	2880	2940	3000	3060];

for mouse=1:numAnimals
    for num=1:numel(per_CSon)
        mean_CS(mouse,num)=mean(zAll(mouse,ts1(1,:) < per_CSoff(num) & ts1(1,:) > per_CSon(num),1));
        
    end

end


for mouse=1:numAnimals
 for num=1:numel(per_ITIon)
         mean_ITI(mouse,num)=mean(zAll(mouse,ts1(1,:) < per_ITIoff(num) & ts1(1,:) > per_ITIon(num),1));
   
       
 end
end

%%
%graph individual traces  on one graph

figure (2)
hold on

coloring=[1 0 0; 1 .4 0; 1 .8 0; 1 1 .2; .6 1 .4;.4 .6 .4; .2 .2 .6; 0 0 .4; .4 0 .4;.8 0 .6; 1 0 .4; .2 1 1; 0 0 0; .7 .7 .7; .8 1 .6; .6 0 0];
a=0;
b=[0 90 210];
shadeTop=1.05*max(max(zAll));
legend([p1],{'Tone'},'Location','northwest')

for allTraces=1:numAnimals
    name=Table.animalNames{allTraces};
    plot(ts1, zAll(allTraces,:), 'color',coloring(allTraces,:), 'LineWidth', 1,'DisplayName',name); hold on;
end

set(gca,'Layer','top')

%%
%separate graphs
figure (3)
hold on
for allTraces=1:numAnimals
    subplot(numAnimals, 1, allTraces)
    
    a=0;
  b=[0 90 210];
    shadeTop=1.05*max(zAll(allTraces,:));
    for ii=1:50
        a=a+60;
        p3=patch([a a+30 a+30 a], [-5 -5 20 20], [.8 1 1], 'EdgeColor','none');
        
    end
    legend([p3],{'Tone'},'AutoUpdate','off','Position',[.22,.33,.167,.28])
    legend boxoff


    plot(ts1, zAll(allTraces,:), 'color',coloring(allTraces,:), 'LineWidth', 1); hold on;
    title(animalNames{allTraces})
    if allTraces~=numAnimals
        set(gca,'xtick',[])
    end
    set(gca,'Layer','top')
  set(get(gca,'title'),'Position',[-150,.85*max(zAll(allTraces,:))]); hold on
end

%%
%Bin trials early/mid/late


%find pt closest to zero in ts1
stt=1; stop=999;
while stt<numel(ts1)&stop>1
    if ts1(stt)<=0
        stt=stt+1;
    else
        stop=0;
    end
    
end
Tri1stt=ts1(stt); %use this time stamp to align all trials

WINDOW = [-2 33];
FirstTri=zAnimalAll(ts1>=WINDOW(1) & ts1<= WINDOW(2));
stamps=ts1(ts1>=WINDOW(1) & ts1<= WINDOW(2));
num_stamps=numel(FirstTri);
samples_per_s=num_stamps/(WINDOW(2)-WINDOW(1));
nextTri=samples_per_s*60; %timestamps per 35 seconds

First5(1,:)=FirstTri;
t1=stamps(1);

for collect=2:5
    t1=t1+nextTri;
    First5(collect,:)=zAnimalAll(t1:t1+num_stamps-1);
end



AvFirst5=mean(First5,1);

figure (4)
p5=patch([0 30 30 0], [-20 -20 20 20], [.8 1 1], 'EdgeColor','none');hold on;
plot(stamps,AvFirst5);hold on;
title('First Five Trials Aligned to Tone Onset')
set(gca,'Layer','top')

