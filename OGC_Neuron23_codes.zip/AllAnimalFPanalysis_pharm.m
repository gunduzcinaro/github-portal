%collect all animal names and blockpaths from user, label blockpaths with

animalNames= {
'C34016A';
'C34017B';
};
blockpaths={
'Z:\Elise Van Leer\GRABeCBv2.7 IL-BLA\Pharmacology\WIN 5\C34016_C34017-230612-093724'...
'Z:\Elise Van Leer\GRABeCBv2.7 IL-BLA\Pharmacology\WIN 5\C34016_C34017-230612-093724'...
};
whichStreams=[34;12];

% 'Veh', 'WIN', 'RIM', 'URB597', 'JZL184', or 'JZL195' will automatically change TRANGE and Baseline
% periods based on set trial times
trial='WIN';
dose = '5 mg';

if strcmpi(trial,'Veh')
    TRANGE = [-300 3100]; % -180 3150 window si ze [start time relative to epoc onset, window duration]
    per_on=[-300 500];
    per_off=[0 2700];
elseif strcmpi(trial,'WIN')
    TRANGE = [-300 3100]; % -180 3150 window si ze [start time relative to epoc onset, window duration]
    per_on=[-300 500];
    per_off=[0 2700];
elseif strcmpi(trial,'RIM')
    TRANGE = [-300 3100]; % -180 3150 window si ze [start time relative to epoc onset, window duration]
    per_on=[-300 300];
    per_off=[0 2800];
elseif strcmpi(trial,'URB597')
    TRANGE = [-300 9000]; % -180 3150 window si ze [start time relative to epoc onset, window duration]
    per_on=[-300 1000];
    per_off=[0 6000];
elseif strcmpi(trial,'JZL184')
    TRANGE = [-300 9300]; % -180 3150 window si ze [start time relative to epoc onset, window duration]
    per_on=[-300 500];
    per_off=[0 7200];
elseif strcmpi (trial,'JZL195')
    TRANGE = [-300 7500]; % -180 3150 window si ze [start time relative to epoc onset, window duration]
    per_on=[-300 2000];
    per_off=[0 5500];
end
BASELINE_PER = [-300 0]; % -180 0 baseline period within our window

numAnimals=numel(animalNames);
dataStruct_names=animalNames;
startTime=zeros(1,numAnimals);
Channel_405_name=animalNames;
Channel_465_name=animalNames;

%make table with all animal info

Table=table(animalNames,blockpaths',dataStruct_names,startTime',Channel_405_name,Channel_465_name,whichStreams);
Headers={'animalNames','blockpath','dataStruct_names','startTime','Channel_405_name','Channel_465_name','whichStreams'};
Table.Properties.VariableNames([1:7])=Headers;
% %fill in animal names

%%

%run TDTbin2mat on all of these, fill in the table, and store the datastructures in workspace
%for each animal....

for aaa=1:numAnimals
    animalName=Table.animalNames{aaa};
    blockpath=Table.blockpath{aaa};
    whichStreams=Table.whichStreams(aaa);
    [zAnimalAll,zerrAnimal,ts1,Chan405,Chan465] =FP_pharm_analysis_streams_corrfull(animalName,blockpath,whichStreams,TRANGE,BASELINE_PER);
    %change NEWNAME=zAnimalAll
    Table.Channel_405_name(aaa)={Chan405};
    Table.Channel_465_name(aaa)={Chan465};
    %the correction below will adjust data points according to the first
    %inputed dataset.  This needs to be changed in case later sessions are
    %shorter (rather than longer) than the first.  THis error is only a
    %difference of one value - it's just because of the way the data are
    %truncated.
    if aaa>1 
        if numel(zAnimalAll)> numel(zAll(1,:))
            disp('time vector has one more element')
            newCol=numel(zAll(1,:));
            zAnimalAll=zAnimalAll(1,1:newCol);
            ts1=ts1(1,1:newCol);
        elseif numel(zAnimalAll)<numel(zAll(1,:))
            zAll=zAll(:,1:numel(zAnimalAll));
            ts1=ts1(1:numel(zAll(1,:)));
            disp('time vector has one less element')
        end
    end
    
    zAll(aaa,:)=zAnimalAll;
    Zerr(aaa,:)=zerrAnimal;
    
   
end
%%
%make user check table



%collect z scores

%%
[~,cols]=size(zAll);

for ii=1:cols
    zAvg(ii)=mean(zAll(:,ii));
    values=zAll(:,ii);
    stdDev(ii)=std(values);
end

SEM=stdDev./(sqrt(numAnimals));
lo=zAvg-SEM;
hi=zAvg+SEM;

%%
AUC={};

for mouse=1:numAnimals
    
    for num=1:numel(per_on)
        AUC{mouse,num}=trapz(zAll(mouse,ts1(1,:) < per_off(num) & ts1(1,:) > per_on(num)));
        timenorm_AUC{mouse,num}=AUC{mouse,num}/(per_off(num)-per_on(num));
    end

end

%% 
%
figure(1)
hold on

% Plot vertical line at epoch onset, time = 0

%for loop for 5 tone retrieval- retrieval is 50 tones though??

xxx=[ts1, ts1(end:-1:1)];
yyy=[lo, hi(end:-1:1)];

hp= fill(xxx,yyy,[ .8 .8 .8]); hold on;
set(hp,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on;
p3=plot(ts1, zAvg, 'k', 'LineWidth', 1,'DisplayName','z-score'); hold on;

set(gca,'Layer','top')
xlabel('Time(s)')
ylabel('Z-Score')
set(gca,'fontsize',20)
xlim([-350 9000])
ylim([-5 5])
%% 
%export to excel
filename = 'GRABeCBv2.7 Pharm AUC + Z-Scores.xlsx'; %name file with exported data

col = {'Mouse ID'; ['AUC ',num2str(per_on(1)),'-',num2str(per_off(1))]; ['AUC ',num2str(per_on(2)),'-',num2str(per_off(2))]; 'Time Norm Pre'; 'Time Norm Post'; 'Time'}; %change columns based on data needed
sheetname = 'WIN 5 mg n=2 Males';

writecell(col.', filename, 'Sheet', sheetname, 'Range', 'A1');
writecell(animalNames, filename, 'Sheet', sheetname, 'Range', 'A2');
writecell(AUC(:,1), filename, 'Sheet', sheetname, 'Range', 'B2');
writecell(AUC(:,2), filename, 'Sheet', sheetname, 'Range', 'C2');
writecell(timenorm_AUC(:,1), filename, 'Sheet', sheetname, 'Range', 'D2');
writecell(timenorm_AUC(:,2), filename, 'Sheet', sheetname, 'Range', 'E2');
writematrix(ts1.', filename, 'Sheet', sheetname, 'Range', 'F2')

writecell(animalNames.', filename, 'Sheet', sheetname, 'Range', 'G1');
columns = {'G2'; 'H2'; 'I2'; 'J2'; 'K2'; 'L2'; 'M2'; 'N2'; 'O2'; 'P2'; 'Q2'; 'R2'; 'S2'; 'T2'};
for n=1:numAnimals
    writematrix(zAll(n,:).', filename, 'Sheet', sheetname, 'Range', columns{n});
end

%%
%graph individual traces  on one graph

figure (2)
hold on

coloring=[1 0 0; 1 .4 0; 1 .8 0; 1 1 .2; .6 1 .4;.4 .6 .4; .2 .2 .6; 0 0 .4; .4 0 .4;.8 0 .6; 1 0 .4; .2 1 1; 0 0 0; .7 .7 .7; .8 1 .6; .6 0 0];
a=0;
b=[0 90 210];
shadeTop=1.05*max(max(zAll));

for allTraces=1:numAnimals
    name=Table.animalNames{allTraces};
    plot(ts1, zAll(allTraces,:), 'color',coloring(allTraces,:), 'LineWidth', 1,'DisplayName',name); hold on;
end

set(gca,'Layer','top')

%%
%separate graphs
figure (3)
hold on
for allTraces=1:numAnimals
    subplot(numAnimals, 1, allTraces)
    
    a=0;
  b=[0 90 210];
    shadeTop=1.05*max(zAll(allTraces,:));
    for ii=1:50
        a=a+60;
        p3=patch([a a+30 a+30 a], [-5 -5 20 20], [.8 1 1], 'EdgeColor','none');
        
    end
    legend([p3],{'Tone'},'AutoUpdate','off','Position',[.22,.33,.167,.28])
    legend boxoff


    plot(ts1, zAll(allTraces,:), 'color',coloring(allTraces,:), 'LineWidth', 1); hold on;
    title(animalNames{allTraces})
    if allTraces~=numAnimals
        set(gca,'xtick',[])
    end
    set(gca,'Layer','top')
  set(get(gca,'title'),'Position',[-150,.85*max(zAll(allTraces,:))]); hold on
end

%%
%Bin trials early/mid/late


%find pt closest to zero in ts1
stt=1; stop=999;
while stt<numel(ts1)&stop>1
    if ts1(stt)<=0
        stt=stt+1;
    else
        stop=0;
    end
    
end
Tri1stt=ts1(stt); %use this time stamp to align all trials

WINDOW = [-2 33];
FirstTri=zAnimalAll(ts1>=WINDOW(1) & ts1<= WINDOW(2));
stamps=ts1(ts1>=WINDOW(1) & ts1<= WINDOW(2));
num_stamps=numel(FirstTri);
samples_per_s=num_stamps/(WINDOW(2)-WINDOW(1));
nextTri=samples_per_s*60; %timestamps per 35 seconds

First5(1,:)=FirstTri;
t1=stamps(1);

for collect=2:5
    t1=t1+nextTri;
    First5(collect,:)=zAnimalAll(t1:t1+num_stamps-1);
end



AvFirst5=mean(First5,1);

figure (4)
p5=patch([0 30 30 0], [-20 -20 20 20], [.8 1 1], 'EdgeColor','none');hold on;
plot(stamps,AvFirst5);hold on;
title('First Five Trials Aligned to Tone Onset')
set(gca,'Layer','top')

