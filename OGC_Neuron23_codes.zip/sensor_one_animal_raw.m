data=TDTbin2mat_OG('Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Cond\C34008A_C34009B-230605-101528');
streams=34;

%%
 
data.epocs.Session.name = 'Session';
data.epocs.Session.onset =data.epocs.TTL_.offset(1); %251.5244 341.5244 461.5244
data.epocs.Session.offset = data.epocs.TTL_.offset(1)+ [28]; %%changed to 30 from 28
%because of TTL error\
nextOffset=1;
while data.epocs.TTL_.offset(nextOffset)<180
    nextOffset=nextOffset+1;
    data.epocs.Session.onset=data.epocs.TTL_.offset(nextOffset);
    data.epocs.Session.offset = data.epocs.Session.onset + [28];%%changed to 30 from 28
    fprintf ('choosing data.epocs.TTL_.offset(%f) for session onset\n',nextOffset);
end

data.epocs.Session.data = [1];
%find channel names
streamNames=fieldnames(data.streams);
if streams==12
    stream1=1; stream2=2;
elseif streams==34
    stream1=3; stream2=4;
end

%%
%use TDT filter to get just the trials you want
EPOC = 'Session'; %set which epoc to look at
STREAM_STORE1 = streamNames{stream1}; %put here what your 405 channel is
STREAM_STORE2 = streamNames{stream2}; %put here what your 465 channel is
TRANGE = [-300 9000]; % -180 3150 window si ze [start time relative to epoc onset, window duration]
BASELINE_PER = [-300 0]; % -180 0 baseline period within our window
ARTIFACT = Inf; %optionally set an artifact rejection level
data = TDTfilter(data,EPOC,'TIME',TRANGE); %perform TDTfilter 

%%
% Optionally remove artifacts. If any waveform is above ARTIFACT level, or
% below -ARTIFACT level, remove it from the data set.
art1 = ~cellfun('isempty', cellfun(@(x) x(x>ARTIFACT), data.streams.(STREAM_STORE1).filtered, 'UniformOutput',false));
art2 = ~cellfun('isempty', cellfun(@(x) x(x<-ARTIFACT), data.streams.(STREAM_STORE1).filtered, 'UniformOutput',false));
good = ~art1 & ~art2;
data.streams.(STREAM_STORE1).filtered = data.streams.(STREAM_STORE1).filtered(good);

art1 = ~cellfun('isempty', cellfun(@(x) x(x>ARTIFACT), data.streams.(STREAM_STORE2).filtered, 'UniformOutput',false));
art2 = ~cellfun('isempty', cellfun(@(x) x(x<-ARTIFACT), data.streams.(STREAM_STORE2).filtered, 'UniformOutput',false));
good2 = ~art1 & ~art2;
data.streams.(STREAM_STORE2).filtered = data.streams.(STREAM_STORE2).filtered(good2);

numArtifacts = sum(~good) + sum(~good2);

%%
% Applying a time filter to a uniformly sampled signal means that the
% length of each segment could vary by one sample.  Let's find the minimum
% length so we can trim the excess off before calculating the mean.
minLength1 = min(cellfun('prodofsize', data.streams.(STREAM_STORE1).filtered));
minLength2 = min(cellfun('prodofsize', data.streams.(STREAM_STORE2).filtered));
data.streams.(STREAM_STORE1).filtered = cellfun(@(x) x(1:minLength1), data.streams.(STREAM_STORE1).filtered, 'UniformOutput',false);
data.streams.(STREAM_STORE2).filtered = cellfun(@(x) x(1:minLength2), data.streams.(STREAM_STORE2).filtered, 'UniformOutput',false);

allSignals = cell2mat(data.streams.(STREAM_STORE1).filtered');

% downsample 10x and average 405 signal
N = 500;
F405 = zeros(size(allSignals(:,1:N:end-N+1)));
for ii = 1:size(allSignals,1)
    F405(ii,:) = arrayfun(@(i) mean(allSignals(ii,i:i+N-1)),1:N:length(allSignals)-N+1);
end
minLength1 = size(F405,2);

% Create mean signal, standard error of signal, and DC offset of 405 signal
meanSignal1 = mean(F405,1);
stdSignal1 = std(double(F405))/sqrt(size(F405,1));
dcSignal1 = mean(meanSignal1);

% downsample 10x and average 465 signal
allSignals = cell2mat(data.streams.(STREAM_STORE2).filtered');
F465 = zeros(size(allSignals(:,1:N:end-N+1)));
for ii = 1:size(allSignals,1)
    F465(ii,:) = arrayfun(@(i) mean(allSignals(ii,i:i+N-1)),1:N:length(allSignals)-N+1);
end
minLength2 = size(F465,2);

% Create mean signal, standard error of signal, and DC offset of 465 signal
meanSignal2 = mean(F465,1);
stdSignal2 = std(double(F465))/sqrt(size(F465,1));
dcSignal2 = mean(meanSignal2);

%% Plot Epoch Averaged Response

% Create the time vector for each stream store
ts1 = TRANGE(1) + (1:minLength1) / data.streams.(STREAM_STORE1).fs*N;
ts2 = TRANGE(1) + (1:minLength2) / data.streams.(STREAM_STORE2).fs*N;

% Subtract DC offset to get signals on top of one another
meanSignal1 = meanSignal1 - dcSignal1;
meanSignal2 = meanSignal2 - dcSignal2;



%% 
% Fitting 405 channel onto 465 channel to detrend signal bleaching
% Scale and fit data
% Algorithm sourced from Tom Davidson's Github:
% https://github.com/tjd2002/tjd-shared-code/blob/master/matlab/photometry/FP_normalize.m

bls = polyfit( F405(1:end),F465(1:end), 1);
Y_fit_all = bls(1) .* F405 + bls(2);
Y_dF_all = F465 - Y_fit_all;

zall = zeros(size(Y_dF_all));
tmp = 0;
for i = 1:size(Y_dF_all,1)
    ind = ts2(1,:) < BASELINE_PER(2) & ts2(1,:) > BASELINE_PER(1);
    zb = mean(Y_dF_all(i,ind)); % baseline period mean (-10sec to -6sec)
    zsd = std(Y_dF_all(i,ind)); % baseline period stdev
    for j = 1:size(Y_dF_all,2) % Z score per bin
        tmp = tmp + 1;
        zall(i,tmp)=(Y_dF_all(i,j) - zb)/zsd;
    end
    tmp=0;
end

% Standard error of the z-score
zerror = std(zall)/size(zall,1);

%%

%FIGURE 1: RAW DATA


figure (1)
hold on 

plot(ts1, F465, 'r'); hold on;
plot(ts2, F405, 'k'); hold on;
xlim([-180 650])
ylim([500 550])
set(gca,'fontsize',20)

%%
%FIGURE 2: z score

figure(2)

hold on
plot(ts1, zall, 'b')
set(gca,'fontsize',20)

xlabel('Time(s)')
ylabel('Z-Score')
xlim([-180 300])
ylim([-2 2])
set(gca,'fontsize',20)
%% 
% FIGURE 3: Combo image
figure (3)
hold on

% %for conditioning
% shadeTop=10;
% a=0;
% b=[0 90 210];
% for ii=1:3
%     a=b(ii);
%     p1=patch([a a+28 a+28 a], [-20 -20 shadeTop shadeTop], [.8 1 1], 'EdgeColor','none');
%     p2=patch([a+28 a+30 a+30 a+28],[-20 -20 shadeTop shadeTop], [1 .8 .8],'EdgeColor','none');
% end 

% % for extinction
% a=0;
% for ii=1:50
%     p1=patch([a a+30 a+30 a], [-150 -150 20 20], [.8 1 1], 'EdgeColor','none');
%     a=a+60;
% end 

plot(ts1,F465-F465(1), 'r');hold on; 
plot(ts1,F405-F405(1), 'k');hold on; 
plot(ts1,zall,'color','b');
set(gca,'fontsize',20)

xlabel('Time(s)')
%ylabel('Z-Score')
% xlim([-5 65])
% ylim([-60 10])
set(gca,'fontsize',20)
%% 
f465_plot = F465-F465(1);
f405_plot = F405-F405(1);

%% Find mean + 2SD for 3 US

shk1_start=find(ts1<28.1 & ts1>=28,1);
shk1_stop=find(ts1<30.1 & ts1>=30,1);

mean_1=mean(meanSignal1(:,shk1_start:shk1_stop));
shk1_2sd=std(meanSignal1(:,shk1_start:shk1_stop))*2;

shk2_start=find(ts1<118.1 & ts1>=118,1);
shk2_stop=find(ts1<120.1 & ts1>=120,1);

mean_2=mean(meanSignal1(:,shk2_start:shk2_stop)');
shk2_2sd=std(meanSignal1(:,shk2_start:shk2_stop))*2;

shk3_start=find(ts1<238.1 & ts1>=238,1);
shk3_stop=find(ts1<240.1 & ts1>=240,1);

mean_3=mean(meanSignal1(:,shk3_start:shk3_stop)');
shk3_2sd=std(meanSignal1(:,shk3_start:shk3_stop))*2;

filename = 'Grab Control Descriptive Stats.xlsx'; %name of file with exported data

columns = {'US 1'; 'US 2'; 'US 3'}; %change name of columns based on data needed
row = {'Mean'; 'Mean+2SD'; 'Mean-2SD'};
sheet = {'B11743'};

shk1 = [mean_1; mean_1 + shk1_2sd; mean_1 - shk1_2sd];
shk2 = [mean_2; mean_2 + shk2_2sd; mean_2 - shk2_2sd];
shk3 = [mean_3; mean_3 + shk3_2sd; mean_3 - shk3_2sd];

writecell(columns.', filename, 'Sheet', sheet{i}, 'Range', 'B1'); %column headers
writecell(row, filename, 'Sheet', sheet{i}, 'Range', 'A2');
writematrix(shk1, filename, 'Sheet', sheet{i}, 'Range', 'B2'); %column headers
writematrix(shk2, filename, 'Sheet', sheet{i}, 'Range', 'C2'); %column headers
writematrix(shk3, filename, 'Sheet', sheet{i}, 'Range', 'D2'); %column headers


%% Find mean + 2SD for 3 tones

tone1_start=find(ts1<0.1 & ts1>=0,1);
tone1_stop=find(ts1<30.1 & ts1>=30,1);

mean_1=mean(meanSignal1(:,tone1_start:tone1_stop));
tone1_2sd=std(meanSignal1(:,tone1_start:tone1_stop))*2;

tone2_start=find(ts1<90.1 & ts1>=90,1);
tone2_stop=find(ts1<120.1 & ts1>=120,1);

mean_2=mean(meanSignal1(:,tone2_start:tone2_stop)');
tone2_2sd=std(meanSignal1(:,tone2_start:tone2_stop))*2;

tone3_start=find(ts1<210.1 & ts1>=210,1);
tone3_stop=find(ts1<240.1 & ts1>=240,1);

mean_3=mean(meanSignal1(:,tone3_start:tone3_stop)');
tone3_2sd=std(meanSignal1(:,tone3_start:tone3_stop))*2;

filename = 'Grab Mut Descriptive Stats.xlsx'; %name of file with exported data

columns = {'Tone 1'; 'Tone 2'; 'Tone 3'}; %change name of columns based on data needed
row = {'Mean'; 'Mean+2SD'; 'Mean-2SD'};
sheet = {'B42487B'};

tone1 = [mean_1; mean_1 + tone1_2sd; mean_1 - tone1_2sd];
tone2 = [mean_2; mean_2 + tone2_2sd; mean_2 - tone2_2sd];
tone3 = [mean_3; mean_3 + tone3_2sd; mean_3 - tone3_2sd];

writecell(columns.', filename, 'Sheet', sheet{i}, 'Range', 'B1'); %column headers
writecell(row, filename, 'Sheet', sheet{i}, 'Range', 'A2');
writematrix(tone1, filename, 'Sheet', sheet{i}, 'Range', 'B2'); %column headers
writematrix(tone2, filename, 'Sheet', sheet{i}, 'Range', 'C2'); %column headers
writematrix(tone3, filename, 'Sheet', sheet{i}, 'Range', 'D2'); %column headers


%% AUC Trial
AUC=[]; % cue, shock
for qq = 1:size(zall,1) %qq = 2:3:size(zall_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC(qq,1)=trapz(zall(qq,ts1(1,:) >= -300 & ts1(1,:) < 0));
    AUC(qq,2)=trapz(zall(qq,ts1(1,:) > 300 & ts1(1,:) < 3600));
    qq=qq+1;
end
AUC_mean = nanmean(AUC); %calculate mean ignoring NaNs
AUC_SEM = nanstd(AUC)/sqrt(numel(AUC(:,1))); %calculate SEM without NaNs

%% AUC Trial
AUC=[]; % cue, shock
for qq = 1:size(zall,1); %qq = 2:3:size(zall_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC(qq,1)=trapz(zall(qq,ts1(1,:) >= -1800& ts1(1,:) < 0));
    AUC(qq,2)=trapz(zall(qq,ts1(1,:) > 0 & ts1(1,:) < 6300));
    AUC(qq,3)=trapz(zall(qq,ts1(1,:) > 6300 & ts1(1,:) < 10000));
    qq=qq+1;
end
AUC_mean = nanmean(AUC); %calculate mean ignoring NaNs
AUC_SEM = nanstd(AUC)/sqrt(numel(AUC(:,1))); %calculate SEM without NaNs

%% AUC trial delete this
AUC=[]; % cue, shock
for qq = 1:size(F405,1); %qq = 2:3:size(zall_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC(qq,1)=trapz(F405(qq,ts1(1,:) >= -180 & ts1(1,:) < 500));
    AUC(qq,2)=trapz(F405(qq,ts1(1,:) > 28 & ts1(1,:) < 30));
    qq=qq+1;
end
AUC_mean = nanmean(AUC); %calculate mean ignoring NaNs
AUC_SEM = nanstd(AUC)/sqrt(numel(AUC(:,1))); %calculate SEM without NaNs
