
%% 
%collect all animal names and blockpaths from user, label blockpaths with
animalNames={'C34016A';...
'C34017B';...
};

blockpaths={
'Z:\Elise Van Leer\GRABeCBv2.7 IL-BLA\Fear\Tanks\Ren\C34016_C34017-230609-131713'...
'Z:\Elise Van Leer\GRABeCBv2.7 IL-BLA\Fear\Tanks\Ren\C34016_C34017-230609-131713'...
};
whichStreams=[34;12];


TRANGE = [-180 480]; %  window size [start time relative to epoc onset, window duration]
BASELINE_PER = [-180 0]; % baseline period within our window
N = 1000;

numAnimals=numel(animalNames);
dataStruct_names=animalNames;
startTime=zeros(1,numAnimals);
Channel_405_name=animalNames;
Channel_465_name=animalNames;

%make table with all animal info

Table=table(animalNames,blockpaths',dataStruct_names,startTime',Channel_405_name,Channel_465_name,whichStreams);
Headers={'animalNames','blockpath','dataStruct_names','startTime','Channel_405_name','Channel_465_name','whichStreams'};
Table.Properties.VariableNames([1:7])=Headers;
% %fill in animal names


%%

%run TDTbin2mat on all of these, fill in the table, and store the datastructures in workspace
%for each animal....

for aaa=1:numAnimals
    animalName=Table.animalNames{aaa};
    blockpath=Table.blockpath{aaa};
    whichStreams=Table.whichStreams(aaa);
    [zAnimalAll,zerrAnimal,ts1,Chan405,Chan465] =FP_ret_analysis_with30sITI_streams_corrfull(animalName,blockpath,whichStreams,aaa,TRANGE,BASELINE_PER,N);
    %change NEWNAME=zAnimalAll
    Table.Channel_405_name(aaa)={Chan405};
    Table.Channel_465_name(aaa)={Chan465};
    %the correction below will adjust data points according to the first
    %inputed dataset.  This needs to be changed in case later sessions are
    %shorter (rather than longer) than the first.  THis error is only a
    %difference of one value - it's just because of the way the data are
    %truncated.
    if aaa>1 
        if numel(zAnimalAll)> numel(zAll(1,:))
            disp('time vector has one more element')
            newCol=numel(zAll(1,:));
            zAnimalAll=zAnimalAll(1,1:newCol);
            ts1=ts1(1,1:newCol);
        elseif numel(zAnimalAll)<numel(zAll(1,:))
            zAll=zAll(:,1:numel(zAnimalAll));
            ts1=ts1(1:numel(zAll(1,:)));
            disp('time vector has one less element')
        end
    end
    
    zAll(aaa,:)=zAnimalAll;
    Zerr(aaa,:)=zerrAnimal;
    
   
end
%%
%make user check table



%collect z scores

%%
[~,cols]=size(zAll);

for ii=1:cols
    zAvg(ii)=mean(zAll(:,ii));
    values=zAll(:,ii);
    stdDev(ii)=std(values);
end

SEM=stdDev./(sqrt(numAnimals));
lo=zAvg-SEM;
hi=zAvg+SEM;

figure(1)

hold on

% Plot vertical line at epoch onset, time = 0

%for loop for 5 tone retrieval- retrieval is 50 tones though??

a=0;
for ii=1:5
    p1=patch([a a+30 a+30 a], [-5 -5 20 20], [.8 1 1], 'EdgeColor','none');
    a=a+60;
end 

xxx=[ts1, ts1(end:-1:1)];
yyy=[lo, hi(end:-1:1)];

hp= fill(xxx,yyy,[ .8 .8 .8]); hold on;
set(hp,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on;
p3=plot(ts1, zAvg, 'k', 'LineWidth', 1,'DisplayName','z-score'); hold on;

% Make a legend
legend([p1 p3 hp],{'Tone','z-score','SEM'}, 'AutoUpdate', 'off');

set(gca,'Layer','top')
xlabel('Time(s)')
ylabel('Z-Score')
xlim([-200 300])
ylim([-5 5])
set(gca,'fontsize',20)


%%
AUC={};
per_on=[-60	0	30	60	90	120	150	180	210	240	270];
per_off=[0	30	60	90	120	150	180	210	240	270]; 


for mouse=1:numAnimals
    
    for num=1:numel(per_on)
        AUC{mouse,num}=trapz(zAll(mouse,ts1(1,:) < per_off(num) & ts1(1,:) > per_on(num)));
        
    end

end


 %%
  
  
per_CSon=[ 0 60 120 180 240 ];
per_CSoff=[ 30	90	150	210	270];

per_ITIon=[ 30	90	150	210	270];
per_ITIoff=[60 120 180 240];

for mouse=1:numAnimals
    for num=1:numel(per_CSon)
        mean_CS(mouse,num)=mean(zAll(mouse,ts1(1,:) < per_CSoff(num) & ts1(1,:) > per_CSon(num),1));
        
    end

end


for mouse=1:numAnimals
 for num=1:numel(per_ITIon)
         mean_ITI(mouse,num)=mean(zAll(mouse,ts1(1,:) < per_ITIoff(num) & ts1(1,:) > per_ITIon(num),1));
   
       
 end
end

%%
%graph individual traces  on one graph

figure (2)
hold on

coloring=[1 0 0; 1 .4 0; 1 .8 0; 1 1 .2; .6 1 .4;.4 .6 .4; .2 .2 .6; 0 0 .4; .4 0 .4;.8 0 .6; 1 0 .4; .2 1 1; 0 0 0; .7 .7 .7; .8 1 .6; .6 0 0];
a=0;
b=[0 90 210];
shadeTop=1.05*max(max(zAll));
for ii=1:5
    p1=patch([a a+30 a+30 a], [-5 -5 20 20], [.8 1 1], 'EdgeColor','none');
    a=a+60;
end 
legend([p1],{'Tone'},'Location','northwest')

for allTraces=1:numAnimals
    name=Table.animalNames{allTraces};
    plot(ts1, zAll(allTraces,:), 'color',coloring(allTraces,:), 'LineWidth', 1,'DisplayName',name); hold on;
end

set(gca,'Layer','top')

%%
%separate graphs
figure (3)
hold on
for allTraces=1:numAnimals
    subplot(numAnimals, 1, allTraces)
    
    a=0;
  b=[0 90 210];
    shadeTop=1.05*max(zAll(allTraces,:));
    for ii=1:5
        a=a+60;
        p3=patch([a a+30 a+30 a], [-5 -5 20 20], [.8 1 1], 'EdgeColor','none');
        
    end
    legend([p3],{'Tone'},'AutoUpdate','off','Position',[.22,.33,.167,.28])
    legend boxoff


    plot(ts1, zAll(allTraces,:), 'color',coloring(allTraces,:), 'LineWidth', 1); hold on;
    title(animalNames{allTraces})
    if allTraces~=numAnimals
        set(gca,'xtick',[])
    end
    set(gca,'Layer','top')
  set(get(gca,'title'),'Position',[-150,.85*max(zAll(allTraces,:))]); hold on
end

%%
%Bin trials early/mid/late


%find pt closest to zero in ts1
stt=1; stop=999;
while stt<numel(ts1)&stop>1
    if ts1(stt)<=0
        stt=stt+1;
    else
        stop=0;
    end
    
end
Tri1stt=ts1(stt); %use this time stamp to align all trials

WINDOW = [-2 33];
FirstTri=zAnimalAll(ts1>=WINDOW(1) & ts1<= WINDOW(2));
stamps=ts1(ts1>=WINDOW(1) & ts1<= WINDOW(2));
num_stamps=numel(FirstTri);
samples_per_s=num_stamps/(WINDOW(2)-WINDOW(1));
nextTri=samples_per_s*60; %timestamps per 35 seconds

First5(1,:)=FirstTri;
t1=stamps(1);

for collect=2:5
    t1=t1+nextTri;
    First5(collect,:)=zAnimalAll(t1:t1+num_stamps-1);
end



AvFirst5=mean(First5,1);

figure (4)
p5=patch([0 30 30 0], [-20 -20 20 20], [.8 1 1], 'EdgeColor','none');hold on;
plot(stamps,AvFirst5);hold on;
title('First Five Trials Aligned to Tone Onset')
set(gca,'Layer','top')

