 %%
%collect all animal names and blockpaths from user, label blockpaths with
animalNames={
'C34008A';
'C34009B';
};
blockpaths={'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Cond\C34008A_C34009B-230605-101528'...
'Z:\Ozge Gunduz Cinar\photometry\GrabAEAv1.5\Fear\Tanks\Cond\C34008A_C34009B-230605-101528'...
};
whichStreams=[34;12];

%AUC time ranges
csonbsl_auc=[-5 0]; cson_auc=[0 28]; csoffbsl_auc=[25 30]; csoff_auc=[30 60]; usbsl_auc=[23 28]; us_auc=[28 30];

% set baseline periods for analysis
TRANGE = [-5 65]; % window size [start time relative to epoc onset, window duration]
BSL_PER = [-5 0]; % baseline period within our window **[-5 0] **
BSL_ITI_PER = [25 30];
BSL_SHK_PER = [23 28];
N = 500;

numAnimals=numel(animalNames);
dataStruct_names=animalNames;
startTime=zeros(1,numAnimals);
Channel_405_name=animalNames;
Channel_465_name=animalNames;

%make table with all animal info

Table=table(animalNames,blockpaths',dataStruct_names,startTime',Channel_405_name,Channel_465_name,whichStreams);
Headers={'animalNames','blockpath','dataStruct_names','startTime','Channel_405_name','Channel_465_name','whichStreams'};
Table.Properties.VariableNames([1:7])=Headers;
% %fill in animal names

%%

%run TDTbin2mat on all of these, fill in the table, and store the datastructures in workspace
%for each animal....
zAll={}; minCols=0;
for aaa=1:numAnimals
    animalName=Table.animalNames{aaa};
    blockpath=Table.blockpath{aaa};
    whichStreams=Table.whichStreams(aaa);
        
    [zAllind, zerr,ts1,zBL4ITI, zBL4shk]=FP_cond_w_nBL(animalName,blockpath,whichStreams,aaa,TRANGE,BSL_PER,BSL_ITI_PER,BSL_SHK_PER,N);
    zAll{aaa,1}=zAllind; %store z scores of individual animals in row of ZAll corresponding to animal 
    zBL4ITI_all{aaa,1}=zBL4ITI;
    zBL4shk_all{aaa,1}=zBL4shk;
    
end
%%
%CONVERT TO MATRIX  - initially store in cell just in case data from dif
%files for some reason aren't the same length. If they aren't, code will
%error here but you won't lose zAll in cell array form
zall_mat=cell2mat(zAll);
clear zAll %clear zall_all to save space
    
zBL4ITI_mat=cell2mat(zBL4ITI_all);
clear zBL4ITI_all %clear zall_all to save space

zBL4shk_mat=cell2mat(zBL4shk_all);
clear zBL4shk_all %clear zall_all to save space

%GET AVERAGE ACROSS ALL ANIMALS, ALL CSs (basically assumes that all
%CSs is equal, and doesn't care which animal contributes which trial
zall_mean=mean(zall_mat,1);
sd_zall=std(zall_mat,1);

%%
%FIGURE 1: AVERAGE OF ALL ANIMALS, ALL CSs
%just looking at whole average before breaking down into bins...
figure (1)
hold on
a=0;

p1=patch([a a+28 a+28 a], [-8 -8 22 22], [.8 1 1], 'EdgeColor','none');
patch([28 30 30 28], [-8 -8 22 22], [1 .8 .8], 'EdgeColor','none')
%p4=patch([a+28 a+30 a+30 a+28], [-4 -4 22 22], [1 .8.8],'EdgeColor','none');


lo=zall_mean-sd_zall;
hi=zall_mean+sd_zall;
xxx1=[ts1, ts1(end:-1:1)];
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[ .8 .8 .8]); hold on;
set(hp1,'FaceColor', [ .8 .8 .8],'EdgeColor','none');hold on;
set(gca,'Layer','Top')
plot(ts1,zall_mean);
title('All Animals, All CSs') %all CSs bins averaged together and baselined to -5s before
xlim([-10 60])
ylim([-8 8])
set(gca,'fontsize',20)
%%
%BINS: Now, we'll organize data into bins. For now, we'll do bins of 3 CSs
%per bin

z_bin5={};first5={};last5={};z_bin_nBL={}; z_bin_shk={};
bin_size=1; %modify this to change how many CSs per bin 1 to look one by one and 3 to look for all as bin!!!
CStot=3; %enter total number of CSs - you can have matlab look for this, but for now I'm just hard coding this value assuming ext is always 30 CSs
num_bins=CStot/bin_size;


for bin = 1:num_bins
    %set bin
    a=bin_size*(bin-1)+1;
    z_this_bin=[];z_this_bin_nBL=[]; z_this_bin_shk=[];
    %locate animal and compile first [bin size] for each animal
    for mouse=1:numAnimals
        
        start=3*(mouse-1);%this assumes there are 3 CSs per animal (which should be true, but careful if you change protocol)
        start=start+a; fin=start+(bin_size-1); % change this 2 according to bin number-1.!!!
        z_this_bin= [z_this_bin; zall_mat(start:fin,:)];
        z_this_bin_nBL=[z_this_bin_nBL; zBL4ITI_mat(start:fin,:)];
        z_this_bin_shk=[z_this_bin_shk; zBL4shk_mat(start:fin,:)];
     
        if bin==1
            zCS1(mouse,:)=zall_mat(start,:);
            first5{mouse,1}=mean(zall_mat(start:fin,:),1); %average of first five CSs for each mouse (each mouse is one row)
            zs_bin1=z_this_bin; %will be helpful if you later need to exclude
            zs_bin1_nBL=z_this_bin_nBL; %will be helpful if you later need to exclude
            zs_bin1_shk=z_this_bin_shk;
      
        elseif bin ==num_bins
            last5{mouse,1}=mean(zall_mat(start:fin,:),1);%average of last five CSs for each mouse (each mouse is one row)
            zs_bin10=z_this_bin;%will be helpful if you later need to exclude
            zs_bin10_nBL=z_this_bin_nBL;
            zs_bin10_shk=z_this_bin_shk;
            
        end
        
        
    end
    
    
    %average across animals
    
    %Below will use each animal's data to find mean for each bin and SEM
    %across animals for that particular bin
    z_bin{bin,1}=mean(z_this_bin,1);
    bin_sd{bin,1}=(std(z_this_bin,1))./((numel(z_this_bin(:,1)))^.5);% sd is actually SEM as of 10/24/2019
    z_bin_nBL{bin,1}=mean(z_this_bin_nBL,1);
    bin_sd_nBL{bin,1}=(std(z_this_bin_nBL,1))./((numel(z_this_bin_nBL(:,1)))^.5);% sd is actually SEM as of 10/24/2019
    z_bin_shk{bin,1}=mean(z_this_bin_shk,1);
    bin_sd_shk{bin,1}=(std(z_this_bin_shk,1))./((numel(z_this_bin_shk(:,1)))^.5);% sd is actually SEM as of 10/24/2019
end

%%
%Figure 2: First  CSs
%short traces

figure (2)
hold on
plot([0;0],[-20; 20],'--','color',[.8 .8 .8],'LineWidth',2);

%%p1=patch([a a+28 a+28 a], [-8 -8 22 22], [.8 1 1], 'EdgeColor','none'); % from first graph for shaded part
%%patch([28 30 30 28], [-8 -8 22 22], [1 .8 .8], 'EdgeColor','none'); % from first graph for shaded part

%SD bin 1
lo=z_bin{1,1}-bin_sd{1,1}; % in Z bin rows are bins 1 to n. change row index. 
hi=z_bin{1,1}+bin_sd{1,1};
% lo=mean_zbin1_ex-bin1_ex_sd;
% hi=mean_zbin1_ex+bin1_ex_sd;
xxx1=[ts1, ts1(end:-1:1)];%used to be ts1_all{1,:} instead of ts1? maybe related to OFL analysis
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[.96 .47 .49],'facealpha',.5); hold on; %old green was 0 .5 .1
set(hp1,'FaceColor', [.96 .47 .49],'EdgeColor','none');hold on;


% 
% %SD bin 10
% lo=z_bin{10,1}-bin_sd{10,1};
% hi=z_bin{10,1}+bin_sd{10,1};
% xxx1=[ts1_all{1,:}, ts1_all{1,:}(end:-1:1)];
% yyy1=[lo, hi(end:-1:1)];
% hp1= fill(xxx1,yyy1,[.56 .02 .03],'facealpha',.5); hold on;
% set(hp1,'FaceColor', [.56 .02 .03],'EdgeColor','none');hold on;



% p1to3=plot(ts1,mean_zbin1_ex,'color',[.96 .47 .49],'LineWidth',2);
p1to5=plot(ts1,z_bin{1,1},'color',[.96 .47 .49],'LineWidth',2); hold on; %light red


%add scale bar
% plot([-8; -7], [0;0],'-k', [0; 0], [7;8],'k', 'LineWidth',2);

% text(-4.2, -1.5, 'z=1', 'HorizontalAlignment','right');
% text(-3.5, -2.5, '1 s', 'HorizontalAlignment','center');
% set(gca, 'XTick',[],'XTickLabel',[],'xcolor',[1 1 1]);
title('CS Onset') %('ALL CS all animals, baselined to 5 sec before CS') % first CS (or bin depending on what was the bin size across all animals together and baselined to -5s before
xlabel('Time(s)')
ylabel('Z-Score')
xlim([-5 30])
ylim([-2 4])
set(gca,'fontsize',20)

%%
%Looking at ITI 
%Here, we'll baseline to t=23 to t=28 (taking t=0 to be CS onset)

%Figure 3: CS Offset
%short traces

figure (3)
hold on
plot([28;28],[-20; 20],'--','color',[.8 .8 .8],'LineWidth',2);% plots a dotted line to the US


%SD bin 1
lo=z_bin_nBL{1,1}-bin_sd_nBL{1,1};
hi=z_bin_nBL{1,1}+bin_sd_nBL{1,1};
% lo=mean_zbin1_ex-bin1_ex_sd;
% hi=mean_zbin1_ex+bin1_ex_sd;
xxx1=[ts1, ts1(end:-1:1)];%used to be ts1_all{1,:} instead of ts1? maybe related to OFL analysis
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[.96 .47 .49],'facealpha',.5); hold on; %old green was 0 .5 .1
set(hp1,'FaceColor', [.96 .47 .49],'EdgeColor','none');hold on;
% 
% %SD bin 10
% lo=z_bin{10,1}-bin_sd{10,1};
% hi=z_bin{10,1}+bin_sd{10,1};
% xxx1=[ts1_all{1,:}, ts1_all{1,:}(end:-1:1)];
% yyy1=[lo, hi(end:-1:1)];
% hp1= fill(xxx1,yyy1,[.56 .02 .03],'facealpha',.5); hold on;
% set(hp1,'FaceColor', [.56 .02 .03],'EdgeColor','none');hold on;

% p1to3=plot(ts1,mean_zbin1_ex,'color',[.96 .47 .49],'LineWidth',2);
p28to30=plot(ts1,z_bin_nBL{1,1},'color',[.96 .47 .49],'LineWidth',2); hold on; %light red

%add scale bar
% plot([-8; -7], [0;0],'-k', [0; 0], [7;8],'k', 'LineWidth',2);

% text(-4.2, -1.5, 'z=1', 'HorizontalAlignment','right');
% text(-3.5, -2.5, '1 s', 'HorizontalAlignment','center');
% set(gca, 'XTick',[],'XTickLabel',[],'xcolor',[1 1 1]);

title('CS Offset') %title('ALL ITI all animals, baselined to 5 sec before shock onset') % first CS across all animals together and baselined to -5s before
xlabel('Time(s)')
ylabel('Z-Score')
xlim([23 60])
ylim([-2 4])
set(gca,'fontsize',20)
%% %%
%Looking at ITI 
%Here, we'll baseline to t=26 to t=28 (taking t=0 to be US onset)

%Figure 4: US Onset
%short traces

figure (4)
hold on
plot([28;28],[-20; 20],'--','color',[.8 .8 .8],'LineWidth',2);% plots a dotted line to the US


%SD bin 1
lo=z_bin_shk{1,1}-bin_sd_shk{1,1};
hi=z_bin_shk{1,1}+bin_sd_shk{1,1};
% lo=mean_zbin1_ex-bin1_ex_sd;
% hi=mean_zbin1_ex+bin1_ex_sd;
xxx1=[ts1, ts1(end:-1:1)];%used to be ts1_all{1,:} instead of ts1? maybe related to OFL analysis
yyy1=[lo, hi(end:-1:1)];
hp1= fill(xxx1,yyy1,[.96 .47 .49],'facealpha',.5); hold on; %old green was 0 .5 .1
set(hp1,'FaceColor', [.96 .47 .49],'EdgeColor','none');hold on;
% 
% %SD bin 10
% lo=z_bin{10,1}-bin_sd{10,1};
% hi=z_bin{10,1}+bin_sd{10,1};
% xxx1=[ts1_all{1,:}, ts1_all{1,:}(end:-1:1)];
% yyy1=[lo, hi(end:-1:1)];
% hp1= fill(xxx1,yyy1,[.56 .02 .03],'facealpha',.5); hold on;
% set(hp1,'FaceColor', [.56 .02 .03],'EdgeColor','none');hold on;

% p1to3=plot(ts1,mean_zbin1_ex,'color',[.96 .47 .49],'LineWidth',2);
p28to30=plot(ts1,z_bin_shk{1,1},'color',[.96 .47 .49],'LineWidth',2); hold on; %light red

%add scale bar
% plot([-8; -7], [0;0],'-k', [0; 0], [7;8],'k', 'LineWidth',2);

% text(-4.2, -1.5, 'z=1', 'HorizontalAlignment','right');
% text(-3.5, -2.5, '1 s', 'HorizontalAlignment','center');
% set(gca, 'XTick',[],'XTickLabel',[],'xcolor',[1 1 1]);

title('US Onset') %title('ALL ITI all animals, baselined to 5 sec before shock onset') % first CS across all animals together and baselined to -5s before
xlabel('Time(s)')
ylabel('Z-Score')
xlim([23 36])
ylim([-2 8])
set(gca,'fontsize',20)

%%

AUC=[]; % cue, shock
for qq = 1:size(zall_mat,1) %qq = 2:3:size(zall_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC(qq,1)=trapz(zall_mat(qq,ts1(1,:) >= csonbsl_auc(1) & ts1(1,:) < csonbsl_auc(2))); %baseline
    AUC(qq,2)=trapz(zall_mat(qq,ts1(1,:) >cson_auc(1) & ts1(1,:) < cson_auc(2))); %CS onset
%     AUC(qq,3)=trapz(zall_mat(qq,ts1(1,:) >30 & ts1(1,:) < 60)); %baseline
%     AUC(qq,4)=trapz(zall_mat(qq,ts1(1,:) >28 & ts1(1,:) < 30)); %CS onset
%     AUC(qq,5)=trapz(zall_mat(qq,ts1(1,:) >30 & ts1(1,:) < 35)); %baseline
    qq=qq+1;
end
AUC_mean = nanmean(AUC); %calculate mean ignoring NaNs
AUC_SEM = nanstd(AUC)/sqrt(numel(AUC(:,1))); %calculate SEM without NaNs

%% 
%zBL4ITI_mat (for looking at the ITIs)

for qq = 1:size(zall_mat,1) %qq = 2:3:size(zall_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC(qq,3)=trapz(zBL4ITI_mat(qq,ts1(1,:) >csoffbsl_auc(1) & ts1(1,:) < csoffbsl_auc(2))); %CS offset baseline
    AUC(qq,4)=trapz(zBL4ITI_mat(qq,ts1(1,:) >csoff_auc(1) & ts1(1,:) < csoff_auc(2))); %CS offset
    qq=qq+1;
end
AUC_mean = nanmean(AUC); %calculate mean ignoring NaNs
AUC_SEM = nanstd(AUC)/sqrt(numel(AUC(:,1))); %calculate SEM without NaNs


%%
%zBL4SHK_mat (for looking at US)

for qq = 1:size(zBL4ITI_mat,1) %qq = 2:3:size(zBL4ITI_mat,1); 1st number which row to start the loop in 2nd # how many rows to skip
    AUC(qq,5)=trapz(zBL4shk_mat(qq,ts1(1,:) >= usbsl_auc(1) & ts1(1,:) < usbsl_auc(2))); %    AUC(qq,1)=trapz(zBL4ITI_mat(qq,ts1(1,:) >= 23 & ts1(1,:) < 28));
    AUC(qq,6)=trapz(zBL4shk_mat(qq,ts1(1,:) > us_auc(1) & ts1(1,:) < us_auc(2)));
%     AUC(qq,7)=trapz(zBL4shk_mat(qq,ts1(1,:) > 30 & ts1(1,:) < 35));
    qq=qq+1;
end
AUC_mean = nanmean(AUC); %calculate mean ignoring NaNs
AUC_SEM = nanstd(AUC)/sqrt(numel(AUC(:,1))); %calculate SEM without NaNs

% %% Find max during ITI and CS
% 
% % to find the ITI and CS start 
% shk_start=find(ts1<28.1&ts1>=28,1);
% shk_stop=find(ts1<33.1&ts1>=33,1);
% 
% max_shk=max(zBL4shk_mat(:,shk_start:shk_stop)');

%%
% average AUC per animal
indAUC_avg=[];

for i=1:numAnimals
    for n=1:size(AUC,2)
        indAUC_avg(i,n)=mean(AUC(i*3-2:i*3,n));
    end
end

%%
%export to excel

filename = 'GRAB AEAv1.5 IL-BLA CS-US n=2 N=500 Cond 3 CS-US.xlsx'; %name file with exported data

num_CS = 3;
num_el = 1:numAnimals*num_CS;
mouse_num = ones(num_CS*numAnimals, 1);
animal_name = {};
for num=1:numAnimals
    for n=1:num_CS
        animal_name{end+1}= animalNames{num};
    end
end
CS_num = [];
for num=1:numAnimals
    mouse_num(num_CS*num-(num_CS-1):num_CS*num)=num;
    CS_num=[CS_num 1:num_CS];
end

csonbsltime=csonbsl_auc(2)-csonbsl_auc(1);    csontime=cson_auc(2)-cson_auc(1);    csoffbsltime=csoffbsl_auc(2)-csoffbsl_auc(1);
csofftime=csoff_auc(2)-csoff_auc(1);    usbsltime=usbsl_auc(2)-usbsl_auc(1);    ustime=us_auc(2)-us_auc(1);
timenorm_headers={'#', 'Mouse #', 'Mouse ID', 'CS #', 'CS Onset Pre', 'CS Onset Post',...
        'CS Offset Pre', 'CS Offset Post', 'US Onset Pre', 'US Onset Post'};
auc_headers={'#', 'Mouse #', 'Mouse ID', 'CS #', 'AUC '+string(csonbsl_auc(1))+'-'+string(csonbsl_auc(2)),...
    'AUC '+string(cson_auc(1))+'-'+string(cson_auc(2)), 'AUC '+string(csoffbsl_auc(1))+'-'+string(csoffbsl_auc(2)),... 
    'AUC '+string(csoff_auc(1))+'-'+string(csoff_auc(2)), 'AUC '+string(usbsl_auc(1))+'-'+string(usbsl_auc(2)),...
    'AUC '+string(us_auc(1))+'-'+string(us_auc(2))};

indAUCtn_avg=[];
indAUCtn_avg(:,1)=indAUC_avg(:,1)/csonbsltime;
indAUCtn_avg(:,2)=indAUC_avg(:,2)/csontime;
indAUCtn_avg(:,3)=indAUC_avg(:,3)/csoffbsltime;
indAUCtn_avg(:,4)=indAUC_avg(:,4)/csofftime;
indAUCtn_avg(:,5)=indAUC_avg(:,5)/usbsltime;
indAUCtn_avg(:,6)=indAUC_avg(:,6)/ustime;


if bin_size==3
    sheetname = 'Z-Score CS-US Avg';

    zscoreavg=table(ts1.',z_bin{1,1}.',bin_sd{1,1}.',z_bin_nBL{1,1}.',bin_sd_nBL{1,1}.',z_bin_shk{1,1}.',bin_sd_shk{1,1}');
    Headers={'ts1', 'Z-Score CS Onset', 'SEM CS Onset', 'Z-Score CS Offset', 'SEM CS Offset', 'Z-Score US', 'SEM US'};
    zscoreavg.Properties.VariableNames(1:7)=cellstr(Headers);
    
    writetable(zscoreavg, filename, 'Sheet', sheetname, 'Range', 'A1');
    
    sheetname = 'Time Norm AUC';

    timenormauc=table(num_el(:),mouse_num,animal_name.',CS_num(:),AUC(:,1)/csonbsltime,AUC(:,2)/csontime,AUC(:,3)/csoffbsltime, ...
        AUC(:,4)/csofftime,AUC(:,5)/usbsltime,AUC(:,6)/ustime);
    timenormauc.Properties.VariableNames(1:10)=cellstr(timenorm_headers);

    writetable(timenormauc, filename, 'Sheet', sheetname, 'Range', 'A1');

    sheetname = 'Time Norm AUC Per Animal';
    tnauc_ind=table(animalNames, indAUCtn_avg(:,1),indAUCtn_avg(:,2),indAUCtn_avg(:,3),indAUCtn_avg(:,4),indAUCtn_avg(:,5),indAUCtn_avg(:,6));
    headers={'Mouse ID', 'CS On Bsl', 'CS On', 'CS Off Bsl', 'CS Off', 'US Bsl', 'US'};
    tnauc_ind.Properties.VariableNames(1:7)=cellstr(headers);

    writetable(tnauc_ind, filename, 'Sheet', sheetname, 'Range', 'A1');

    sheetname = 'AUC Cond';
    
    auc_cond=table(num_el(:),mouse_num,animal_name.',CS_num(:),AUC(:,1),AUC(:,2),AUC(:,3),AUC(:,4),AUC(:,5),AUC(:,6));
    auc_cond.Properties.VariableNames(1:10)=cellstr(auc_headers);
    
    writetable(auc_cond, filename, 'Sheet', sheetname, 'Range', 'A1');

    sheetname = 'AUC Per Animal';
    auc_ind=table(animalNames, indAUC_avg(:,1),indAUC_avg(:,2),indAUC_avg(:,3),indAUC_avg(:,4),indAUC_avg(:,5),indAUC_avg(:,6));
    headers={'Mouse ID', 'CS On Bsl', 'CS On', 'CS Off Bsl', 'CS Off', 'US Bsl', 'US'};
    auc_ind.Properties.VariableNames(1:7)=cellstr(headers);

    writetable(auc_ind, filename, 'Sheet', sheetname, 'Range', 'A1');
    
elseif bin_size==1
    for n=1:num_CS
        sheetname = 'Z-Score CS-US'+string(n);
        zscore=table(ts1.',z_bin{n,1}.',bin_sd{n,1}.',z_bin_nBL{n,1}.',bin_sd_nBL{n,1}.',z_bin_shk{n,1}.',bin_sd_shk{n,1}');
        Headers={'ts1', 'Z-Score CS'+string(n)+' Onset', 'SEM CS'+string(n)+' Onset', 'Z-Score CS'+string(n)+' Offset', 'SEM CS'+string(n)+' Offset', 'Z-Score US'+string(n), 'SEM US'+string(n)};
        zscore.Properties.VariableNames(1:7)=cellstr(Headers);
        writetable(zscore, filename, 'Sheet', sheetname, 'Range', 'A1');
    end

    sheetname = 'Time Norm AUC';

    timenormauc=table(num_el(:),mouse_num,animal_name.',CS_num(:),AUC(:,1)/csonbsltime,AUC(:,2)/csontime,AUC(:,3)/csoffbsltime, ...
        AUC(:,4)/csofftime,AUC(:,5)/usbsltime,AUC(:,6)/ustime);
    timenormauc.Properties.VariableNames(1:10)=cellstr(timenorm_headers);
    timenormauc_sort=sortrows(timenormauc,'CS #');

    writetable(timenormauc_sort, filename, 'Sheet', sheetname, 'Range', 'A1');

    sheetname = 'AUC Cond';
    
    auc_cond=table(num_el(:),mouse_num,animal_name.',CS_num(:),AUC(:,1),AUC(:,2),AUC(:,3),AUC(:,4),AUC(:,5),AUC(:,6));
    auc_cond.Properties.VariableNames(1:10)=cellstr(auc_headers);
    auc_cond_sort=sortrows(auc_cond,'CS #');

    writetable(auc_cond_sort, filename, 'Sheet', sheetname, 'Range', 'A1');

end
